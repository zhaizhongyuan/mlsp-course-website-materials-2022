import numpy as np
import librosa
from sklearn.cluster import KMeans
import sys
from python_speech_features import mfcc
import scipy.io.wavfile as wav

def MFCC(filepath):
    rate, sig = wav.read(filepath)
    mfccs = mfcc(sig, rate, numcep=24)
    return mfccs

def mcd(C, C_hat):
    """C and C_hat are NumPy arrays of shape (T, D),
    representing mel-cepstral coefficients.

    """
    K = 10 / np.log(10) * np.sqrt(2)
    return K * np.mean(np.sqrt(np.sum((C - C_hat) ** 2, axis=1)))

original = './English.wav'
env = './env.wav'
env2 = './env2.wav'
print("Remove Spikes median, self_angle: ", mcd(MFCC(env), MFCC(original)))
print("Remove Spikes mean, self_angle: ", mcd(MFCC(env2), MFCC(original)))

env_denoised = './env_denoised.wav'
env2_denoised = './env2_denoised.wav'
print("Remove Spikes median and denoised, self_angle: ", mcd(MFCC(env_denoised), MFCC(original)))
print("Remove Spikes mean and denoised, self_angle: ", mcd(MFCC(env2_denoised), MFCC(original)))

denoise = './denoised.wav'
print("SC denoised, self_angle: ", mcd(MFCC(denoise), MFCC(original)))