import numpy as np
import librosa
from sklearn.cluster import KMeans
import sys
from python_speech_features import mfcc
import scipy.io.wavfile as wav

def MFCC(filepath):
    rate, sig = wav.read(filepath)
    mfccs = mfcc(sig, rate, numcep=24)
    return mfccs

def VTLN(X, Y):
    W = np.dot(X, np.linalg.pinv(Y))
    return W

def Map_from_L1(X, Y, W):
    # X: matrix of row vectors 
    # Y: matrix of row vectors 
    # res: matrix of row vectors
    res_Y = Clustering_L1(X, Y, W)
    return res_Y

def Map_from_L2(X, Y, W):
    # X: matrix of row vectors 
    # Y: matrix of row vectors 
    # res: matrix of row vectors
    res_X = Clustering_L2(X, Y, W)
    return res_X

def Clustering_L2(X, Y, W):
    # X: matrix of row vectors
    # Y: matrix of row vectors with more than 512 rows
    # Y: N x D
    assert(Y.shape[0] >= 512)

    kmeans = KMeans(n_clusters=512).fit(Y)
    centroids = kmeans.cluster_centers_
    labels = kmeans.labels_

    assert(centroids.shape[0] == 512)

    res = np.zeros_like(X)
    for X_idx in range(X.shape[0]):
        # loop through clusters to find closest centroids
        min_err = sys.maxsize
        label = None
        for label_idx in range(centroids.shape[0]):
            err = np.linalg.norm(np.dot(W, centroids[label_idx].T) - X[X_idx].T)
            if err < min_err:
                min_err = err
                label = labels[label_idx]
        # loop through data with in clusters to find closest data
        cluster = Y[np.where(labels = label)]
        min_err = sys.maxsize
        pair = None
        for cluster_idx in range(cluster.shape[0]):
            err = np.linalg.norm(np.dot(W, cluster[cluster_idx].T) - X[X_idx].T)
            if err < min_err:
                min_err = err
                pair = cluster[cluster_idx]
        res[X_idx, :] = pair

    return res

def Clustering_L1(X, Y, W):
    # X: matrix of row vectors with more than 512 rows
    # X: N x D
    # Y: matrix of row vectors with more than 512 rows

    assert(X.shape[0] >= 512)

    kmeans = KMeans(n_clusters=512).fit(X)
    centroids = kmeans.cluster_centers_
    labels = kmeans.labels_

    assert(centroids.shape[0] == 512)

    res = np.zeros_like(Y)
    for Y_idx in range(Y.shape[0]):
        # loop through clusters to find closest centroids
        min_err = sys.maxsize
        label = None
        for label_idx in range(centroids.shape[0]):
            err = np.linalg.norm(np.dot(W, Y[Y_idx].T) - centroids[label_idx].T)
            if err < min_err:
                min_err = err
                label = labels[label_idx]
        # loop through data with in clusters to find closest data
        cluster = X[np.where(labels = label)]
        min_err = sys.maxsize
        pair = None
        for cluster_idx in range(cluster.shape[0]):
            err = np.linalg.norm(np.dot(W, Y[Y_idx].T) - cluster[cluster_idx].T)
            if err < min_err:
                min_err = err
                pair = cluster[cluster_idx]
        res[Y_idx, :] = pair

    return res

infile = r"./mandarin11.wav"
infile2 = r"./english5.wav"
x = MFCC(infile)
y = MFCC(infile2)
vtln = VTLN(x, y)
print(x.shape, y.shape)
print(vtln.shape)
print(Map_from_L1(x, y, vtln))