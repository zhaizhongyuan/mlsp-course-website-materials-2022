import numpy as np
from scipy.io.wavfile import read, write
import matplotlib.pyplot as plt
plt.rcParams["figure.figsize"] = [7.50, 3.50]
plt.rcParams["figure.autolayout"] = True
input_data = read("./Indian_male_DTW_self_angle.wav")
audio = input_data[1]
plt.figure(1)
plt.plot(audio)
print(len(audio))
plt.ylabel("Amplitude")
plt.xlabel("Time")



def median(lst): return np.median(np.array(lst))
def mean(lst): return sum(lst)/len(lst)

(fs, x) = read('./Indian_male_DTW_SC.wav')
signs = np.sign(x)
x = abs(x)
plt.plot(range(len(x)), x, color = 'yellow')
env = np.zeros_like(x)
env2 = np.zeros_like(x)

for i in range(len(x)):
    env[i] = median(x[max(i-10,0):i+1])
    env2[i] = mean(x[max(i-10,0):i+1])

write('./env.wav', fs, env * signs)
write('./env2.wav', fs, env2 * signs)


plt.plot(range(len(x)), env * signs, color = 'green')
plt.plot(range(len(x)), env2 * signs, color = 'red')
plt.show()