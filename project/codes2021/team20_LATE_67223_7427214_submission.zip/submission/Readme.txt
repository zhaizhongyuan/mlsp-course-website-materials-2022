Frist assign the training and testing data as the notation. Then code will generate:
1.Target (orignal target for comparision)
2. generated_SC (generated result with SC but not DTW)
3. generated_DTW_SC (generated result with SC and DTW)

At last the code will provide a comparison between correspoding basis for two dictionaries