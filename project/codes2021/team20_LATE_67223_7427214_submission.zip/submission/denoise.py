import noisereduce as nr
from scipy.io.wavfile import read, write
import matplotlib.pyplot as plt
# load data
(rate, data) = read("./Indian_male_DTW_SC.wav")
# perform noise reduction
reduced_noise = nr.reduce_noise(y=data, sr=rate)

write('./denoised.wav', rate, reduced_noise)
plt.figure(0)
plt.plot(data)
plt.figure(1)
plt.plot(reduced_noise)


(rate, data) = read("./env.wav")
reduced_noise = nr.reduce_noise(y=data, sr=rate)
write('./env_denoised.wav', rate, reduced_noise)

(rate, data) = read("./env2.wav")
reduced_noise = nr.reduce_noise(y=data, sr=rate)
write('./env2_denoised.wav', rate, reduced_noise)


plt.show()