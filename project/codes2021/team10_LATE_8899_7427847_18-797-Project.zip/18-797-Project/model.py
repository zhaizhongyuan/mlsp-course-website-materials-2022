from utills.Annotation_Parser import annotation_parser
from utills.Onset_detection import Onset_detection
from utills.Extract_Spectrogram import extract_spectrogram
from utills.score import score

import soundfile as sf
import librosa
from sklearn.decomposition import NMF
import os
import numpy as np
from tqdm import tqdm


def perform_NMF_source(data, min_length, n_components=300,feature="spectrogram"):
    #Spectrogram
    #n_component default 300
    if feature=="spectrogram":
        M = data['M']
    if feature =="time_domain":
        M = data['time_domain']
    new_M = M[:,:min_length]
    
    #beta_loos for KL divergence
    #Solver Mu to use multiplicative update
    model = NMF(n_components=n_components, beta_loss=1, init='random', solver='mu', max_iter=600, random_state=0)
    
    B = model.fit_transform(new_M)
    
    # M =B*H
    data['B'] =B
    data['M'] = new_M
    #data['model'] = model

def seperate_signals(M_mix, base, n_sources, n_iter, n_comps):
    pq = np.ones(M_mix.shape)    
    B =base
    
    W = np.random.rand(B.shape[1],M_mix.shape[1])
    print("starting seperate signals")
    for _ in range(n_iter):
        diff = M_mix/np.dot(B,W)
        W_numer = np.dot(B.T, diff)
        W_denom = np.dot(B.T, pq)
        W = np.multiply(W, W_numer/W_denom)
        
        #Replace 0 with very small number to avoid zero devision
        W[W==0]=0.0001

    seperated_sources = []
    
    for i in range(0,n_sources):
        data = {"W": W[i*n_comps:(i+1)*n_comps,:],
                "B": B[:,i*n_comps:(i+1)*n_comps]}
        seperated_sources.append(data)

    return seperated_sources

class drum_sound_seperation():
    def __init__(self, annotation_directory):
        self.num_comp = 300 
        
        info = annotation_parser(annotation_directory)
        self.audioFileName = info['audioFileName']
        self.audioTraniningFileName = info['audioTrainingFileName']
        self.num_sources = len(self.audioTraniningFileName)

        self.transcription = info['Transcription']
    
        self.min_length = 0
        
        self.hh_train = {
            "M":[],
            "phase":[],
            "time_domain":[],
            "sr": 0,
            "B": []
        }
        self.kd_train= {
            "M":[],
            "phase":[],
            "time_domain":[],
            "sr": 0,
            "B": []
        }

        self.sd_train = {
            "M":[],
            "phase":[],
            "time_domain":[],
            "sr": 0,
            "B": []

        }
        self.mixed = {
            "M":[],
            "phase":[],
            "time_domain":[],
            "sr": 0,
        }
        
        self.hh_seperated = {
            'output': None,
            'annotation': []
        }
        self.kd_seperated = {
            'output': None,
            'annotation': []
        }
        self.sd_seperated = {
            'output': None,
            'annotation': []
        }
        
        self.hh_score= None
        self.kd_score = None
        self.sd_score = None


    def fit(self, feature):
        if feature == "spectrogram":
            lengths = []
            self.mixed['M'], self.mixed['phase'], self.mixed['sr'] = extract_spectrogram(os.path.join("IDMT-SMT-DRUMS-V2/audio", self.audioFileName))
            
            for file in self.audioTraniningFileName:
                if "#HH#" in file:
                    self.hh_train['M'], self.hh_train['phase'], self.hh_train['sr'] = extract_spectrogram(os.path.join("IDMT-SMT-DRUMS-V2/audio", file))
                    lengths.append(self.hh_train['M'].shape[1])
                if "#KD#" in file:
                    self.kd_train['M'], self.kd_train['phase'], self.kd_train['sr'] = extract_spectrogram(os.path.join("IDMT-SMT-DRUMS-V2/audio", file))
                    lengths.append(self.kd_train['M'].shape[1])
                if "#SD#" in file:
                    self.sd_train['M'], self.sd_train['phase'], self.sd_train['sr'] = extract_spectrogram(os.path.join("IDMT-SMT-DRUMS-V2/audio", file))
                    lengths.append(self.sd_train['M'].shape[1])
            
            self.min_length = min(lengths)
        print("Starting HH")
        perform_NMF_source(self.hh_train, self.min_length, n_components=self.num_comp)
        print("Starting KD")
        perform_NMF_source(self.kd_train, self.min_length, n_components=self.num_comp)
        print("Starting SD")
        perform_NMF_source(self.sd_train, self.min_length, n_components=self.num_comp)
        
    def transform(self):
        #HH/KD/SD
        base = [self.hh_train['B'],self.kd_train['B'],self.sd_train['B']]
        base = np.concatenate(base, axis=1)

        seperated_sources = seperate_signals(self.mixed['M'], base, self.num_sources, 400, self.num_comp)

        for index, signal in enumerate(seperated_sources):
            isExist = os.path.exists("output")
            if not isExist:
                os.mkdir("output")
            H = signal['W']
            B = signal['B']
            H[H==0.0001] = 0
            M_test = np.dot(B,H)
            
            if index == 0:
                file_tag = self.audioFileName.split("#")
                output = f"{file_tag[0]}#HH#SEPERATED"
                self.hh_seperated['output'] = output
            
            if index == 1:
                file_tag = self.audioFileName.split("#")
                output = f"{file_tag[0]}#KD#SEPERATED"
                self.kd_seperated['output'] = output
            
            if index == 2:
                file_tag = self.audioFileName.split("#")
                output = f"{file_tag[0]}#SD#SEPERATED"
                self.sd_seperated['output'] = output
            
            signal_hat = librosa.istft(M_test*self.mixed['phase'], hop_length=256, center=False, win_length=1024)
            sf.write(f"output/{output}.wav", signal_hat, samplerate=self.mixed['sr'])
    
    def score(self):
        self.hh_score = score(self.transcription['HH'], self.hh_seperated['annotation'])
        self.kd_score = score(self.transcription['KD'], self.kd_seperated['annotation'])
        self.sd_score = score(self.transcription['SD'], self.sd_seperated['annotation'])

    def check_annotation(self):
        print(self.transcription['HH'])
        print(self.transcription['KD'])
        print(self.transcription['SD'])
    
    def reconstructed_annotation(self):
        self.hh_seperated['annotation'] = Onset_detection(f"output/{self.hh_seperated['output']}.wav")
        self.kd_seperated['annotation'] = Onset_detection(f"output/{self.kd_seperated['output']}.wav")
        self.sd_seperated['annotation'] = Onset_detection(f"output/{self.sd_seperated['output']}.wav")




if __name__=="__main__":
    test = drum_sound_seperation("IDMT-SMT-DRUMS-V2/annotation_xml/RealDrum01_00#MIX.xml")
    test.fit(feature="spectrogram")