def score(answer, estimated):
    len_answer = len(answer)
    len_estimated = len(estimated)
    
    TP = 0
    
    checking_index = 0
    for e in estimated:
        for a in answer:
            if float(a)-0.03 <= e <= float(a)+0.03:
                TP += 1

    if TP > len_answer:
        TP = len_answer
    
    FP = len_estimated-TP
    FN = len_answer - TP

    F = 2*TP / ( (2*TP) +FP+ FN)
    
    return {
        "F":F,
        "answer": len_answer,
        "estimated": len_estimated,
        "TP": TP,
        "FP": FP,
        "FN": FN
    }