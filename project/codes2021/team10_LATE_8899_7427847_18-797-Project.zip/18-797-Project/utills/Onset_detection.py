import librosa
import matplotlib.pyplot as plt
import numpy as np

def Onset_detection(sound_file):
    audio, sr = librosa.load(sound_file, sr=None)
    mean_sound = np.sqrt(np.mean(np.square(audio)))
    audio[audio < mean_sound] = 0
    output = librosa.onset.onset_detect(y=audio, sr=sr)
    output = librosa.frames_to_time(output, sr=sr)
    return output

if __name__=="__main__":
    onset = Onset_detection("output/test_0.wav")
    print(onset)