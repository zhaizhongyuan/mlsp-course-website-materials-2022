import librosa

def extract_spectrogram(data_path):
    audio, sr = librosa.load(data_path, sr=None)
    spectrogram = librosa.stft(audio, n_fft=2048, hop_length=256, center=False, win_length=2048)
    M = abs(spectrogram)
    phase= spectrogram/(M+2.2204e-16)
    
    return M, phase, sr