import xml.etree.ElementTree as ET

Drum_Sources = ['HH', 'KD', 'SD']

def annotation_parser(directory: str):
    tree= ET.parse(directory)
    root= tree.getroot()
    info = {
                "audioFileName": None,
                "audioTrainingFileName": [],
                "Transcription":{
                    "HH":[],
                    "KD":[],
                    "SD":[]
                }
            }
    for child in root:
        if child.tag == "globalParameter":
            for i in child:
                if i.tag == "audioFileName":
                    info['audioFileName'] = i.text
                if i.tag == "audioTrainingFileName":
                    info["audioTrainingFileName"].append(i.text)

        if child.tag == "transcription":
            for i in child:
                if i[3].text == "HH":
                    info["Transcription"]["HH"].append(i[1].text)
                if i[3].text == "KD":
                    info["Transcription"]["KD"].append(i[1].text)
                if i[3].text == "SD":
                    info["Transcription"]["SD"].append(i[1].text)
    return info
         
if __name__=="__main__":
    annotation = annotation_parser("IDMT-SMT-DRUMS-V2/annotation_xml/RealDrum01_00#MIX.xml")
    print(annotation)

    
