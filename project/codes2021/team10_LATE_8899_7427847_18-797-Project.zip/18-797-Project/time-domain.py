"""
Time Domain Feature Extraction and Analysis
"""

import numpy as np
import librosa
import librosa.display
import soundfile as sf
from sklearn.decomposition import NMF
import matplotlib.pyplot as plt

"""
Help on Zero-Crossings from: https://musicinformationretrieval.com/zcr.html
"""

speech = "example/five_hits.wav"
audio, sr = librosa.load(speech, sr=None)
spectrogram = librosa.stft(audio, n_fft=2048, hop_length=256, center=False, win_length=2048)
frames = librosa.util.frame(audio, frame_length=2048, hop_length=256)
windowed_frames = np.hanning(2048).reshape(-1, 1)*frames
Ms = abs(spectrogram)
print("Spectrogram shape", Ms.shape)
print("windowed time domain shape", windowed_frames.shape)
phase_s = spectrogram/(Ms+2.2204e-16)

# Displays of imported audio for debugging
# plt.figure()
# librosa.display.specshow(Ms)
# plt.colorbar()
# plt.show()
# plt.plot(audio)
# plt.title("Sample Audio Waveform")
# plt.show()

"""
Zero Crossing Feature Extraction
"""
# Librosa Zero Crossing Functions
# zero_crossings = librosa.zero_crossings(audio, pad=False) 
zcr = librosa.feature.zero_crossing_rate(audio + 0.0001)

window_length, num_windows = windowed_frames.shape

zcrs = np.zeros(num_windows)
print(zcrs.shape)
for i in range(num_windows):
    # print(windowed_frames[:,i].shape)
    tmp = librosa.zero_crossings(windowed_frames[:,i] + 0.0001)
    # print(tmp.shape)
    tmp = sum(tmp)
    # print(tmp)
    zcrs[i] = tmp

#Checking that windowed zero crossings works vs librosa fn
# fig, axs = plt.subplots(2)
# fig.suptitle('Zero Crossing Rates: Windowing (Top), Normal (Bottom)')
# axs[0].plot(zcrs)
# axs[1].plot(zcr[0])
# plt.show()

rms = librosa.feature.rms(y=audio, frame_length=2048, hop_length=256, center=False)

output = np.zeros((2,num_windows))
output[0,:] = zcrs
output[1,:] = rms[0]
print(output.shape)

fig, axs = plt.subplots(2)
fig.suptitle('Extracted Features per Window')
axs[0].plot(output[0,:])
axs[0].set_title("Zero Crossings")
axs[1].plot(output[1,:])
axs[1].set_title("RMS")
plt.show()
