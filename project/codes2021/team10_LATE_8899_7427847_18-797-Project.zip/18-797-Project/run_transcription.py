from model import drum_sound_seperation
import multiprocessing
import numpy as np
import os

def perform_transcription(annotation_directory):
    model= drum_sound_seperation(annotation_directory)
    model.fit(feature="spectrogram")
    model.transform()
    model.reconstructed_annotation()
    model.score()
    return [model.hh_score, model.kd_score, model.sd_score]

if __name__=="__main__":
    files = os.listdir("IDMT-SMT-DRUMS-V2/annotation_xml")
    xml_files = []
    for i in files:
        if i.endswith("xml"):
            xml_files.append(f"IDMT-SMT-DRUMS-V2/annotation_xml/{i}")
    
    pool_obj = multiprocessing.Pool()
    result = pool_obj.map(perform_transcription, xml_files)
