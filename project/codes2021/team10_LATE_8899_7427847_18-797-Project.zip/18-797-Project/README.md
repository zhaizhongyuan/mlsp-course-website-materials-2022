# 18-797 Project Timbre Sensitive Drum Transcription

## NMF with HW3 Example
### example.ipynb
- Used sklearn for the NMF learning 
- Extracted two different bases from the music and speech wav files
- With Extracted base, extracted W from the mixed wav file
- It's not perfectly correct but hope you guys can get a idea of NMF

## NMF with IDMT-SMT-DRUMS-V2
### Data
- check [Links](https://www.idmt.fraunhofer.de/en/business_units/m2d/smt/drums.html)
- Download IDMT-SMT-DRUMS-V2 Dataset and unzip on the current directory 
- Provided password and links for 18-797 Team
### Data Structure
- audio & annotation_xml
### Annotation_xml
- It contains mix file name and train file names
- Onset and Offset annotation

### IDMT-SMT-DRUMS.ipynb
- Used sklearn for the NMF learning for training set base learning 
- Since we have to only learn H which is the transcription based on the \
  learned bases from above, I used KL divergence based multiplicative method with fixed B
- Check the out wav files it generates

## TO DO 
- xml parsing function which organize the XML files and plot ground truth annotation
- transcription function after isft and try to plot transcription base on the audio data
- Accuracy function
- Post processing function which post process audio file that generates from the NMF
- Currently only uses T-F domain data(STFT), have to perfrom experiment using:
    - zero corssing
    - RMS amplitude
    - etc..
## Warning 
- please don't push IDMT-SMT-DRUMS data 

## Usage
- Created model.py class to perform transcription
- Run run_transcription.py to perfrom transcription
- Saved all the score list as a npy in result 
  - check result directory and import npy file to see the score

- check result.ipynb to see the reuslt directly 