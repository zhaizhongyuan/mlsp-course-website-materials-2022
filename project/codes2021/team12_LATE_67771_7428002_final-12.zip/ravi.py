import pyworld as pw
import librosa
import numpy as np
import matplotlib.pyplot as plt
import soundfile as sf


#x, fs = librosa.load('../../hw1/Audio/BlindingLights.wav', sr = 16000)
x, fs = librosa.load('../../hw1/Misirlou', sr = 16000)
f0,sp,ap = pw.wav2world(x.astype(float), fs)
print(f0.shape)
print(librosa.get_duration(y=x, sr=fs))

x1, fs1 = librosa.load('../../hw1/Audio/BlindingLights.wav', sr = 16000)
f01,sp1,ap1 = pw.wav2world(x1.astype(float), fs1)
sp1 = np.tile(sp1, (39,1))
ap1 = np.tile(ap1, (39,1))
y = pw.synthesize(f0[:77103], sp1, ap1, fs)
sf.write("project.wav", y,16000)
