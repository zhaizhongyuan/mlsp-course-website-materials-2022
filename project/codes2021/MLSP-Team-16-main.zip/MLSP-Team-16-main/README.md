# MLSP-Team-16

Semester long project to track hand movement using optical flow techniques
