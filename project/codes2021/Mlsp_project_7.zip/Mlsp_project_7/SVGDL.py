import numpy as np
from sklearn.decomposition import PCA
from sklearn import svm
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

class ModifiedSVM:
  
  def fit(self, X_train, Y_train, theta, class_label, no_of_iterations, learning_rate=0.01):
    """
    Fits svm classifier on X_train, Y_train using using modified hinge loss formulation i.e. instead of hinge loss
    objective function uses hinge loss function ^ 2.

    Input:
    X_train: (N*D)
    Y_train: (N*1)
    """
    Y_train = Y_train.reshape((-1,1))
    Y_train = np.where(Y_train==class_label, 1, -1)
    (N,D) = X_train.shape
    w = np.zeros((D,1))
    bias = 0.0

    for i in range(0,no_of_iterations):
      w_current = w
      for j in range(0,N):
        # print("value",(np.dot(np.squeeze(w),X_train[j,:]) + bias))
        if (Y_train[j,0]*(np.dot(np.squeeze(w),X_train[j,:]) + bias)) <= 1:
          w = w - learning_rate*((((Y_train[j,0]*(np.dot(np.squeeze(w),X_train[j,:])+bias))-1)*(2*theta*Y_train[j,0])*(X_train[j,:].reshape(-1,1))))
          bias = bias - learning_rate*(((Y_train[j,0]*(np.dot(np.squeeze(w),X_train[j,:])+bias))-1)*(2*theta*Y_train[j,0]))
      
      w = w - learning_rate*w_current

    return (w,bias)
    
class SVGDL:

  def __init__(self):
    """
    Class implementing Support vector guided dictionary learning as describe in (https://link.springer.com/chapter/10.1007/978-3-319-10593-2_41).

    params:
      - D: Dictionary atoms
      - Z: representation matrix
      - U,b: Decision boundaries of the one vs all linear svm classifiers maximizing the discrimination term in the objective.
    """
    self.D = None
    self.Z = None
    self.U = None
    self.b = None


  def dictionary_initialization(self, X, Y, C, pca_energy):
    """
    Initializes the dictionary with the principal components of training data belonging to different classes.
    Input:
      - X: Training data of shape (D,N)
      - Y: Labels of the training data points
      - C: Number of different classes in the training data
      - pca_energy: total energy captured by principal components selected for each class.
    Output:
      - D: Initialized dictionary atoms
    """
    D = None
    flg = 0

    for i in range(1,C+1):
      X_ = X[:,np.squeeze(np.where(Y==i))]
      pca = PCA(n_components=pca_energy, svd_solver = 'full')
      pca.fit(X_.T) # N*D matrix as i/p
      components = pca.components_.T
      if flg == 0:
        D = components
        flg = 1
      else:
        D = np.append(D, components, axis=1)
    
    return D

  def optimizing_Z(self, U, b, D, x, z, class_label, Y, lambda_1, lambda_2, theta, n_itr=10, learning_rate=0.00001):
    """
    Method that optimizes the representation for a given data point using gradient descent.

    Input:
      - U,b: Decision boundaries of the one vs all linear svm classifiers maximizing the discrimination term in the objective. 
      - D: learnt dictionary
      - x: training data point
      - z: current representation of the training data point.
      - Y: class label of traning data point
      - lambda_1: weights of the l2 norm regularizion in the objective function
      - lambda_2,theta: weights of the discrimination term in the objective function
      - n_itr: Number of epochs for which gradient descent runs.
      - learning_rate: learning rate used for gradient descent updates
    Output:
      - z: optimized representation of the given data point
    """
    z = z.reshape((-1,1))
    x = x.reshape((-1,1))

    for i in range(0,n_itr):
      gradient = (-2*D.T@x + 2*D.T@D@z + 2*lambda_1*z).reshape((-1,1))
      for c in range(0,U.shape[1]):
        y = 1 if Y==c else -1
        u = U[:,c].reshape((-1,1))
        if y*(u.T@z + b[0,c]) > 1:
          gradient = gradient + 2*lambda_2*theta*(y*(u.T@z + b[0,c]) - 1)*y*u

      z = z - learning_rate*gradient

    return z 


  def projected_optimization(self, X, Z):
    """
    Method that Optimizes: D←argmin_D ∥X−DZ∥2F s.t.∥di∥2 ≤1,∀i using projected gradients.
    Input:
      - X: Training data points of shape (D,N) where D is the dimentionality and N is the number of training data points
      - Z: Learnt representation of training data points
    Output:
      - Dictionary atoms that minimizes reconstruction error with the constraint that l2 norm of atoms is <= 1.
    """
    D = (X@Z.T)@np.linalg.inv(Z@Z.T) # closed form solution for finding the optimal atoms without factoring in the constrain

    # normalizing the atoms which violate the constraint.
    for i in range(0,D.shape[1]):
      col = D[:,i]
      if col.T@col > 1:
        D[:,i] = col/(col.T@col)
    
    return D

  def learning_bases(self, X, B, S, c, n_itr=100):
    """
    Method that Optimizes: D←argmin D ∥X−DZ∥2F s.t.∥di∥2 ≤1,∀i using lagrange dual formulation.(https://proceedings.neurips.cc/paper/2006/file/2d71b2ae158c7c5912cc0bbde2bb9d95-Paper.pdf)
    Input:
      - X: Training data points
      - B: Learnt Dictionary
      - S: Learnt represention of the training data points
      - c: constraint imposed on the l2 norm of the dictionary atoms
      - n_itr: number of epochs for which the updates are done.
    Output:
      - optimal basis/dictionary
    """
    (N,K) = (B.shape[0], B.shape[1])
    lambda_ = np.zeros((K,1)) # initialization of dual variables to 0

    for i in range(0,n_itr):
      dual_vars = np.zeros((K,K))
      np.fill_diagonal(dual_vars, lambda_)
      tmp = np.linalg.inv(S@S.T + dual_vars)
      first_derivative = np.sum(((X@S.T@tmp@np.identity(K)))**2, axis=0).reshape((-1,1)) - 1
      second_derivative = -2*(tmp@(X@S.T).T@(X@S.T)@tmp)*(tmp)
      lambda_ = lambda_ - np.linalg.pinv(second_derivative)@first_derivative
    
    lamda_diag = np.zeros((K,K))
    np.fill_diagonal(np.zeros((K,K)), lambda_)
    return (np.linalg.inv(S@S.T + lamda_diag)@((X@S.T).T)).T
  
  def compute_loss(self, X, D, Z, Y, C, lambda1=0.002, lambda2=0.002, theta=0.02):
    """
    Method that computes the value of objective function given the current dicitonary, representation of training data points
    Input:
      - X: Training data points
      - D: Learnt Dictionary
      - Z: Learnt representation of training data points
      - Y: labels of training data points
      - C: number of classes in the training data
      - lambda_1: weights of the l2 norm regularizion in the objective function
      - lambda_2,theta: weights of the discrimination term in the objective function
    Output:
      - returns the loss function computed
    """
    loss = np.linalg.norm(X-D@Z)**2 + lambda1*np.linalg.norm(Z)**2

    for c in range(1,C+1):
      u = self.U[:,c-1]
      b = self.b[0,c-1]
      loss += np.linalg.norm(u)

      for i in range(0,self.Z.shape[1]):
        y = 1 if Y[i]==c else -1
        z = self.Z[:,i]
        loss+= max(0,1-(u.T@z + b)*y)
    
    return loss
  
  def normalize_atoms(self, D):
    """
    Method Normalize atoms of dictionary to avoid overflow
    Input:
      - D: learnt dictionary
    Ouput:
      - D: dictionary with normalized atoms 
    """
    for i in range(0,D.shape[1]):
      D[:,i] = D[:,i]/(np.linalg.norm(D[:,i]))
    
    return D

  def fit(self, X, y, C, pca_energy=0.95, lambda1=2000, lambda2=0.01, theta=2):
    """
    Main Method that learns the representation by minimizing the objective as described in (https://link.springer.com/chapter/10.1007/978-3-319-10593-2_41).
    Input:
      - X: training data 
      - y: labels of the training data points.
      - C: number of different classes of training data points
      - pca_energy: energy captured by the prinicipal components selected for initializing the dictionary.
      - lambda_1: weights of the l2 norm regularizion in the objective function
      - lambda_2,theta: weights of the discrimination term in the objective function
    Ouput:
      - D: learnt dictionary
      - U,b: Decision boundaries of the one vs all linear svm classifiers maximizing the discrimination term in the objective. 
    """
    self.D = self.dictionary_initialization(X, y, C, pca_energy)
    self.U = np.zeros((self.D.shape[1], C))
    self.b = np.zeros((1, C))
    self.Z = np.zeros((self.D.shape[1], X.shape[1]))

    D_prev = self.D
    itr = 1

    # convergence condition -> difference between D computed in successive iterations is less than a threshold
    while itr<=20:
      np.save('/content/drive/MyDrive/MLSP/D_'+str(itr), self.D)
      print("Iteration ",itr)
      itr+=1

      U_prev = self.U

      print("Step1 SVM")
      # Step1 train one vs all linear svms for all the c classes and fetch the normal vector, bias of the decision boundary
      for c in range(1,C+1):
        # svm = ModifiedSVM()
        clf = svm.SVC(kernel="linear")
        labels = np.where(y==c, 1, 0)
        clf.fit(self.Z.T, labels)
        (w,b) = (clf.coef_, clf.intercept_)
        # print("w.shape",w.shape)
        self.U[:,c-1] = np.squeeze(w)
        self.b[0,c-1] = b

      print("SVM completed, loss = {loss}".format(loss=self.compute_loss(X,self.D, self.Z, y, C)))
      self.D = self.normalize_atoms(self.D)

      # Step2 updating Z
      for i in range(0,self.Z.shape[1]):
        # print(self.Z[:,i].shape)
        z_opt = self.optimizing_Z(U_prev, self.b, self.D, X[:,i], self.Z[:,i], y[i], lambda1, lambda2, theta, 10)
        # print("z_opt",z_opt)
        self.Z[:,i] = np.squeeze(z_opt)

      print("Z updated, loss = {loss}".format(loss=self.compute_loss(X,self.D, self.Z, y, C)))

      print("Updating D")
      # Step 3 updating D
      self.D = self.learning_bases(X, self.D, self.Z, 1)

      print("D updated, loss = {loss}".format(loss=self.compute_loss(X,self.D, self.Z, y, C)))

      print("Loss is", self.compute_loss(X,self.D, self.Z, y, C))

      print("Classification acc for itr {}, is {}", itr, self.classification_accuracy(X.T, y, self.U, self.b, self.D))
      

      # self.D = self.normalize_atoms(self.D)

    return self.D, self.U, self.b

  def classification(self, U, b, D, x, lambda_1=0.02):
    """
    Computes predicted label for the input x by making use of the learnt decision boundaries.
    Input:
      - U,b: Decision boundaries of the one vs all linear svm classifiers maximizing the discrimination term in the objective. 
      - D: learnt dictionary
      - x: input data point
    Ouput:
      - label: predicted label
    """
    P = np.linalg.inv((D.T)@D + lambda_1*np.identity((D.T).shape[0]))@D.T
    z = P@x.reshape((-1,1))

    confidence_scores = []

    for c in range(0, U.shape[1]):
      uc = U[:,c]
      bc = b[0,c]
      confidence_scores.append(uc.reshape((1,-1))@z.reshape((-1,1))+bc)
    
    confidence_scores = np.array(confidence_scores)
    label = np.argmax(confidence_scores) + 1
    return label

  def classification_accuracy(self, X_test, y_test, U, b, D):
    """
    Method that computes the classification accuracy.
    Input:
      - X_test: test data
      - y_test: corresponding labels of test data
      - U,b: Decision boundaries of the one vs all linear svm classifiers maximizing the discrimination term in the objective. 
      - D: learnt dictionary 
    Output:
      - Returns the accuracy on test data i.e. percentage of test data points classified correctly
    """ 
    (N,_) = X_test.shape
    correct = 0
    for i in range(0,N):
      x = X_test[i,:]
      y_pred = self.classification(U, b, D, x)
      if y_pred==y_test[i]:
        correct = correct + 1
    
    return (correct/N)*100