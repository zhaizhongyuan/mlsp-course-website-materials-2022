from sklearn.decomposition import sparse_encode, PCA, dict_learning
import time
from mrmr import mrmr_classif
import glob
from feature_sign import feature_sign_search
from feature_sign_yang import feature_sign_yang
import math
from sporco.admm import bpdn
from sporco.admm import cmod
import os
from sporco.pgm.backtrack import BacktrackStandard, BacktrackRobust
import pickle
PWD = "/content/drive/MyDrive/18-797 MLSP/MLSP_Project/Code"
# 10 , 0.4; 100,1
class EDL:
  def __init__ (self, k=100, sparse_coder='feature_sign', D=None, A=None, savedir=None):
    self.lambda1 = 40
    self.lambda2_dash = 10
    self.theta = 1e-3
    self.k = k
    self.gamma_init = 0.2
    self.gamma = self.gamma_init
    self.eps1 = 1e-4
    self.eps2 = 1e-4
    self.sparse_coder=sparse_coder
    self.class_divs = []
    self.D_init = D
    if self.D_init is not None:
      self.k = self.D_init.shape[1]
    self.A_init = A
    self.make_savedir(savedir)
    self.best_D = 0
    self.best_A = 0
    self.rounds = 20


  def make_savedir(self,path):
    '''
    Creates a save directory to store results
    args:
      path: directory to create/store at

    '''
    if path is None:
      path = 'runs'
    
    os.makedirs(path,exist_ok=True)
    runs = glob.glob(os.path.join(PWD,path) + '/*')
    self.save_dir = os.path.join(PWD,path,'run{}'.format(len(runs)+1))
    os.makedirs(self.save_dir,exist_ok=True)
  
  def set_params(self, X, y):
    '''
    Initializes variables that will help in faster gradient computation and
    other thresholds required during training.
    args:
      X [D,N]: Input data
      y [N,]: Target variable

    '''
    # class division and indices
    classes,class_divs = np.unique(y,return_counts=True)
    self.train_labels = y.flatten().copy()
    self.class_divs = []
    for i,nums in zip(classes, class_divs):
      self.class_divs.append([i]*nums)
    self.class_divs = np.concatenate(self.class_divs).flatten()

    self.class_divs = self.class_divs.astype(np.int)
    self.class_idxs = [np.where(self.class_divs == c) for c in classes]
    self.classes = classes.astype(np.int)
    self.L = self.classes.shape[0]
    self.lambda2 = self.lambda2_dash*np.sum(X**2)/self.D.shape[1]
   
    # values based on D and A
    self.A_threshold = np.mean(np.abs(self.A))/5
    print("threshold",self.A_threshold)
    self.pred = self.D@self.A 
    self.norm_fro_base = (self.D@self.A - X)
    self.norm_fro_base_2 = np.sum(self.norm_fro_base**2)
    self.A_abs_base = np.sum(np.abs(self.A))
    self.sum_A_rows = np.sum(np.abs(self.A),axis=1)
    self.p_ic = self.get_pc(self.A)
    A_rows = np.tile(self.sum_A_rows,(self.L,1)).T
    self.sum_A_classes = self.p_ic*A_rows
    self.D_2 = self.D**2

  def calc_entropy_f(self):
      '''
      Calculates H(Di) entropy based objective portion.

      '''

      L = self.L
      self.H = np.zeros(self.D.shape[1]) # one entropy per dictionary item
      
      self.p_ic = self.get_pc(self.A) 
      self.ent_p_ic = np.zeros((self.H.shape[0],np.unique(self.class_divs).shape[0]))

      for c in self.classes:
        p_ic_c = self.p_ic[:,c].copy()
        p_ic_c[p_ic_c == 0] = 1
        self.ent_p_ic[:,c] = -1.0*p_ic_c*(np.log(p_ic_c)/np.log(L))

      self.H = np.sum(self.ent_p_ic,axis=0)

  def feature_sign(self, X, D=None, test=True):
    '''
    Calculates A(0) using feature-sign search algo
    args:
      X [N,D] : input features data
    Returns:
      A [K,N] : sparse code matrix
    '''

    if D is None:
      D = self.D
    A_FS = D.T@D + 2e-4*np.eye(D.shape[1])
    B = -D.T@X
    A = np.zeros((self.D.shape[1],X.shape[1]))

    for i in range(B.shape[1]):
      A[:,i] = (feature_sign_yang(A_FS,B[:,i],self.lambda1/2))

    return np.array(A)
  
  def OMP(self,X, D=None, lmbda=None):
    '''
    Calculates A(0) using Orthogonal Matching Pursuit algo
    args:
      X [N,D] : input features data
    Returns:
      A [K,N] : sparse code matrix
    '''

    if lmbda is None:
      lmbda = self.lambda1
    opt = bpdn.BPDN.Options({'Verbose': False, 'MaxMainIter': 50})
    if D is None:
      D =self.D

    A = np.zeros((D.shape[1],X.shape[1]))
    b = bpdn.BPDN(D, X, lmbda, opt)
    A = b.solve()
    A = np.nan_to_num(A)
    print("sparsity",np.mean(np.sum(A!=0,axis=0)))
    return A 


  def reset(self, X, y):
    '''
    Initializes the D and A for first run
    args:
      X [N,D] : input features data
      y [N,] : target variables
    '''
    if self.D_init is None:
      self.D = X[:,np.random.choice(X.shape[1],self.k)].reshape(-1,self.k)
      self.k = self.D.shape[1]

    else:
      self.D = self.D_init.copy()
   
    for i in range(self.D.shape[1]):
      if np.linalg.norm(self.D[:,i]) != 0:
        self.D[:,i] /= np.linalg.norm(self.D[:,i])

    if self.A_init is None:
      print("using ",self.sparse_coder," for A init")
      if self.sparse_coder == 'OMP': 
        self.A = self.OMP(X, self.D)

      elif self.sparse_coder == "feature_sign":
        self.A = self.feature_sign(X)
        
    else:
      self.A = self.A_init.copy()
    self.A = np.nan_to_num(self.A)
    print("D and A shapes:",self.D.shape, self.A.shape)
    

  def objective(self, X, comp_H=True): # same objective as original that means entropy_f is working too
    '''
    Calculates the objective function which contains reconstruction error,
    sparsity constaint and entropy function
    args:
      X[D,N]: Input data
      comp_H: recalculates entropy if set to True, else uses prev value
    Returns:
      objective function value

    '''
    frob_norm = np.linalg.norm((self.D@self.A- X),ord='fro')**2
    l1_norm =  np.sum(np.abs(self.A))
    if comp_H==True:
      self.calc_entropy_f()
    entropy = np.sum(self.H)
    print("objective",frob_norm,l1_norm,entropy)    
    return frob_norm + (self.lambda1 *l1_norm) + (self.lambda2 * entropy)
  
  def ent_sum(self,p_ic):
    '''
    Helper function to calculate entropy sum pertaining to p_ic
    args:
      p_ic: probability mapping of dict atom i to class c
    '''
    p_ic[p_ic == 0] = 1
    E = -1.0 * np.sum(p_ic*(np.log(p_ic)/np.log(p_ic.shape[1])),axis=0)
    assert E is not None, "E ent_sum is None"
    return np.sum(E)

  def train(self, X, y, X_test=0, y_test = 0, DoPass=False):
    '''
    Main training loop
    args:
      X [D,N] : input data feat*instances
      Y [N,] : target labels
    '''
    if not DoPass:
      self.reset(X, y)
      self.set_params(X, y)
      
      self.prev_acc = 0.0
      self.acc =0.0
      loss1 = self.objective(X)
      loss2 = self.objective(X)
      self.best_loss = np.Inf
      self.prev_a = self.A.copy()
      i = 1
   
    for x in range(self.rounds):
      self.set_params(X, y)
      self.prev_obj = None  
      for i in range(self.A.shape[0]):
        
        no_ij_idx = np.where(np.arange(len(self.p_ic)) != i )[0]
        if (i+1)%50 == 0:
          print("row: ,",i+1, " loss = ",self.prev_obj)
          self.save_stuff(pause=True,acc=self.prev_acc)
        self.ent_sum_no_ij = self.ent_sum(self.p_ic[no_ij_idx,:])
        
        for j,jdx in enumerate(np.random.choice(self.A.shape[1],self.A.shape[1]//4,replace=False)):
          self.step_f(X,i,jdx)
        
        if i ==0:
          first_loss = self.prev_obj

      self.prev_A = self.A.copy()
      self.update(X)
      loss1 = self.objective(X)
      print("loss after D updates",loss1)

      if loss1 < self.best_loss:
        self.best_loss = loss1
        self.best_D = self.D.copy()
        self.best_A = self.A.copy()
        if type(X_test) == np.ndarray:
          acc = self.score(X_test,y_test)
          print("test acc:",acc)
          train_acc = self.score(X, y)
          print("train acc:",train_acc)
        if acc > self.prev_acc:
          print('saving')
          self.prev_acc = acc
          self.save_stuff(acc=acc)

      else:
        print("reverting back")
        self.A = self.prev_A.copy()
      
    

  def save_stuff(self,pause = False,acc=0.0):
    '''
    Helper function to save D and A
    args:
      pause: if set True, will save D and A to previous file
      acc: accuracy on test data using current D and A

    '''
    val = len(glob.glob(self.save_dir + "/*"))
    if val == 0:
      num = 0
    else:
      num = int(glob.glob(self.save_dir + "/*")[-1].split('/')[-1][1])

    if not pause:
      D_path = self.save_dir +'/D{}_{:.2f}.pkl'.format(num+1,acc)
      A_path = self.save_dir +'/A{}_{:.2f}.pkl'.format(num+1,acc)
      print("saving at ",D_path)
    else:
      D_path = self.save_dir +'/D{}_{:.2f}.pkl'.format(num,acc)
      A_path = self.save_dir +'/A{}_{:.2f}.pkl'.format(num,acc)
    
    with open(D_path,'wb') as fp:
      pickle.dump(self.D,fp)
    with open(A_path,'wb') as fp:
      pickle.dump(self.A,fp)
    

  def get_pc(self, A, D=None):
    '''
    Calculates pc which maps each dictionary atom to a class c
    args:
      A[K,N]: sparse code matrix
      D[D,K]: Dictionary
    Returns:
      pc[K,C]: probability matrix
    '''
    if D is None:
      D = self.D
    pc = np.zeros((D.shape[1],len(self.classes)))
    l1_norm = np.abs(A, dtype=np.float)
    sum_norm = np.sum(l1_norm,axis=1)
    sum_norm[sum_norm == 0] =1

    for c in self.classes:
        num_norm = l1_norm[:,self.class_idxs[c]].squeeze()
        pc[:,c] += np.sum(num_norm,axis=1)/sum_norm

    return pc

  def ent(self,pc):
    '''
    Helper function to calculate entropy
    args:
      pc[1,C]: prob mapping of atom to classes
    returns:
      entropy of that dictionary atom
    '''
    pc[pc==0] = 1

    return -1.0 * np.sum(pc*np.log(pc)/np.log(self.L))

  def grad(self, X, i, j):
    '''
    Calculates gradient of objective wrt \alpha_{i,j}
    args:
      X[D,N]: Input data
      i,j: indices of the sparse code
    Returns:
      gradient wrt \alpha_{i,j}
    '''
    # calc grad_entropy
    j_class = self.class_divs[j]
    grad_p_ic = []
    sign = np.sign(self.A[i,j]) if self.A[i][j] !=0 else 0.0
    
    sum_ai = np.sum(np.abs(self.A[i,:]))**2
    sum_ai = sum_ai if sum_ai != 0 else 1.

    for c in self.classes:
      l = 0 if self.p_ic[i,c] == 0 else np.log(self.p_ic[i,c])/np.log(len(self.classes))
      if c == j_class:
        num = np.sum(np.abs(self.A[i,np.where(self.class_divs != c)[0]]))/sum_ai* sign
        
        grad_p_ic.append( num*l + (num/np.log(self.L)))

      else:
        num = -1.0* np.sum(np.abs(self.A[i,self.class_idxs[c]]))/sum_ai* sign
        grad_p_ic.append(num*l + (num/np.log(self.L)))

    grad_p_ic = -1.0 * np.array(grad_p_ic)

    
    #zero handling

    
    grad_entropy = np.sum( (grad_p_ic) )
      
    term1 = 2 * ((self.D[:,i].reshape(1,-1)@self.D)@self.A[:,j].reshape(-1,1))[0][0]
    term2 = 2 * (self.D[:,i].reshape(1,-1)@X[:,j].reshape(-1,1))[0][0]
    term3 = self.lambda1*sign
    term4 = self.lambda2*grad_entropy
    # print(term1,term2,term3,term4)
    grad = term1 - term2 + term3 + term4
    return grad

  def update_gamma(self,R):
    '''
    Updates gamma based on objective change for faster convergence
    args:
      R: change in objective function
    '''
    if R > 0:
      self.gamma *= 1.6
    elif R <0:
      self.gamma *= 0.5
    
    self.gamma = max(1e-4,self.gamma)
  
  
  def recompute_obj(self, X, old_alpha, i, j, prev_obj):
    '''
    Recomputes Objective during coordinate descent in a smart way to save time
    and space.
    args:
      X[D,N]: Input data
      old_alpha: previous \alpha_{i,j} value
      i,j : sparse code indices
      prev_obj: objective value
    returns:
      new objective function value after \alpha_{i,j} updates
    '''

    dif = ((self.A[i,j] - old_alpha)*self.D[:,i]).flatten()
    dif_pow2 = dif**2
    toAdd = dif_pow2 + 2*dif*self.norm_fro_base[:,j]
    norm_fro_pow2 = self.norm_fro_base_2 + np.sum(toAdd)
    dif_abs = np.abs(self.A[i,j]) - np.abs(old_alpha)
    
    A_abs = self.A_abs_base + dif_abs
    self.sum_A_classes[i,self.class_divs[j]] += dif_abs
    self.sum_A_rows[i] += dif_abs
    self.sum_A_rows[i] = self.sum_A_rows[i] if self.sum_A_rows[i] != 0 else 1.0

    pc_row = self.sum_A_classes[i,:]/self.sum_A_rows[i]
    self.p_ic[i,:] = pc_row.copy()

    new_obj = norm_fro_pow2 + self.lambda1*A_abs + self.lambda2*(self.ent_sum_no_ij + self.ent(pc_row))

    

    return new_obj,norm_fro_pow2, dif, A_abs
    

  def step_f(self, X, i, j):
    '''
    Computes the update for a single \alpha_{i,j}
    args:
      X[D,N]: Input data
      i,j: sparse code indices
    '''
    if abs(self.A[i,j]) < self.A_threshold:
      return
   
    grad = self.grad(X,i,j)
    R = np.Inf
    if self.prev_obj is None:
      prev_obj = self.objective(X,comp_H=False)
    else:
      prev_obj = self.prev_obj

    steps = 0
    
    #save old stuff
    A_ij_prev = self.A[i,j]
    pc_row_prev = self.p_ic[i,:].copy()
    sum_A_rows_i_prev = self.sum_A_rows[i]
    sum_A_classes_ic_prev = self.sum_A_classes[i,self.class_divs[j]]
    
    while steps < 5 and self.gamma > 0.06:

      self.A[i,j] =  self.A[i,j] - self.gamma*grad 
      new_obj, norm_fro_pow2, dif, A_abs = self.recompute_obj(X,A_ij_prev,i,j, prev_obj)
      
      R = (prev_obj - new_obj)/prev_obj
      self.update_gamma(R)
      if new_obj>prev_obj:
        # worse
        self.A[i,j] = A_ij_prev
        self.p_ic[i,:] = pc_row_prev
        self.sum_A_rows[i] = sum_A_rows_i_prev
        self.sum_A_classes[i,self.class_divs[j]] = sum_A_classes_ic_prev
      else:
        # better
        self.norm_fro_base_2 = norm_fro_pow2
        self.norm_fro_base[:,j] += dif.flatten()
        self.A_abs_base = A_abs
        prev_obj = new_obj
        A_ij_prev = self.A[i,j]
        pc_row_prev = self.p_ic[i,:].copy()
        sum_A_rows_i_prev = self.sum_A_rows[i]
        sum_A_classes_ic_prev = self.sum_A_classes[i,self.class_divs[j]]

      steps += 1

    self.gamma = self.gamma_init
    self.prev_obj = prev_obj
    assert np.isnan(self.A).sum() == 0, print(self.A[i,j],i,j)

  
  def update(self, X):
    '''
    Updates D after one iteration of A update:
    args:
      X[D,N]: Input data
    '''
    # opt = cmod.CnstrMOD.Options({'Verbose': False, 'MaxMainIter': 200,
    #                          'RelStopTol': 1e-4, 'FastSolve':True})
    # c = cmod.CnstrMOD(self.A, X, None, opt)
    # self.D = c.solve()
    self.D = X@np.linalg.pinv(self.A)
    for i in range(self.D.shape[1]):
      if np.linalg.norm(self.D[:,i]) != 0:
        self.D[:,i] /= np.linalg.norm(self.D[:,i])
    # self.D = whiten(self.D.T).T
    self.A = self.OMP(X)
    self.A = np.nan_to_num(self.A)
    self.D = np.nan_to_num(self.D)

    self.pred = self.D@self.A

  def predict(self, X, y=None):
    '''
    Inference using trained or initialized dictionary and sparse codes
    args:
      X [D,N] : input data feat*instances
      Y [N,] : target labels
    returns:
      preds[N,]: predicted classes

    '''
    try:
      print("using def")
      A_test = self.OMP(X, self.best_D, lmbda=self.lambda1*0.6)
      A_train = self.best_A if type(self.best_A) == np.ndarray else self.A
      pic = self.get_pc(A_train)
    except:
      print("using init")
      A_test = self.OMP(X, self.D_init, lmbda=self.lambda1*0.2)
      A_train = self.A_init
      pic = self.get_pc(A_train,self.D_init)
    
    class_logits = pic.T@abs(A_test)
    preds = np.argmax(class_logits, axis=0)
    return preds
  
  def score(self, X, y):
    '''
    Helper function to score the predictions:
    args:
      X [D,N] : input data feat*instances
      Y [N,] : target labels
    returns:
      accuracy
    '''
    preds = self.predict(X, y.flatten())
    print(preds.shape,y.shape)
    correct = (preds.flatten() == y.flatten()).sum()
    acc = correct/len(y) * 100

    return acc
