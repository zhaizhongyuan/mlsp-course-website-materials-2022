import numpy as np 

# min  0.5*x'*A*x+b'*x+\Lambda*|x|



def feature_sign_yang( A, b, Lambda):

  EPS = 1e-9
  x = np.zeros((A.shape[0]))

  grad = A@x + b
  ma = np.max(np.abs(grad)*(x==0))
  mi = np.argmax(np.abs(grad)*(x==0))
  cc = 0

  while True:
    cc += 1
    if cc>1000:
      break
    
    if grad[mi] > Lambda + EPS:
      x[mi] = (Lambda - grad[mi])/A[mi,mi]
    elif grad[mi] < -(Lambda + EPS):
      x[mi] = (-Lambda - grad[mi])/A[mi,mi]
    else:
      if np.all(x==0):
        break
    cc2 = 0
    # print(mi,x[mi])
    # print(xx)
    # print(x)
    while True:
      cc2 += 1
      a = np.where(x!=0)
      # print(a)
      if len(a[0]) >1:
        # print("bro",np.expand_dims(a[0],axis=-1))
        Aa = A[np.expand_dims(a[0],axis=-1),a]
      else:
        Aa = A[a,a]
      ba = b[a]
      xa = x[a]

      # new b based on unchanged sign
      vect = -Lambda*np.sign(xa) - ba
      # print(Aa.shape, vect.shape)
      # print(Aa.shape,vect.shape,"F")
      x_new = np.linalg.solve(Aa,vect)
      # print(x_new)
      idx = np.where(x_new != 0)[0]
      # print(vect[idx]/ + ba[idx],x_new)
      try:
        o_new = (vect[idx]/2 + ba[idx]).T@x_new[idx] + Lambda*sum(abs(x_new[idx]))
      except:
        o_new = (vect[idx]/2 + ba[idx]).T*x_new[idx] + Lambda*sum(abs(x_new[idx]))
      # print(o_new)
      # print(xx)
      s = np.where(xa*x_new <=0)[0]
      # print(s)
      # print(xx)
      if len(s) == 0:
        # print(x[a],x_new)
        x[a] = x_new
        loss = o_new
        break
      
      if(cc2>1000):
        x[a] = x_new
        loss = o_new
        break
      
      x_min = x_new
      o_min = o_new
      d = x_new - xa
      t = d/xa
      # print(x_min,s)
      for zd in s:
        x_s = xa - d/t[zd]
        x_s[zd] = 0
        idx = np.where(x_s != 0)
        try:
          o_s = (vect[idx]/2 + ba[idx]).T@x_new[idx] + Lambda*sum(abs(x_new[idx]))
        except:
          o_s = (vect[idx]/2 + ba[idx]).T*x_new[idx] + Lambda*sum(abs(x_new[idx]))
        if o_s < o_min:
          x_min=x_s
          o_min=o_s
      # print(x[a],x_min)
      x[a]=x_min
      loss=o_min
    
    # print(b)
    grad = A@x + b
    # print(grad)
    ma = max(abs(grad)*(x==0))
    mi = np.argmax(abs(grad)*(x==0))
    # print(ma)
    if ma <= Lambda+EPS:
      # print("ma<=")
      break

  return x

