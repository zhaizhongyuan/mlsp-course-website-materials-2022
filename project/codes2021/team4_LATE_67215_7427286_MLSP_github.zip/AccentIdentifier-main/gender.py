from __future__ import division

import os

import matplotlib.pylab as plt
import soundfile as sf
from numpy import argmax
from numpy import polyfit, arange
from numpy.fft import rfft
from scipy.signal import blackmanharris


def freq_from_HPS(sig, fs):
    """
    Estimate frequency using harmonic product spectrum (HPS)
    """
    windowed = sig * blackmanharris(len(sig))
    from pylab import copy

    # harmonic product spectrum:
    c = abs(rfft(windowed))
    maxharms = 5
    for x in range(2, maxharms):
        a = copy(c[::x])  # Should average or maximum instead of decimating
        # max(c[::x],c[1::x],c[2::x],...)
        c = c[:len(a)]
        i = argmax(abs(c))
        true_i = parabolic(abs(c), i)[0]
        freq = fs * true_i / len(windowed)
        c *= a
    return freq

def parabolic(f, x):
    """Quadratic interpolation for estimating the true position of an
    inter-sample maximum when nearby samples are known.
    f is a vector and x is an index for that vector.
    Returns (vx, vy), the coordinates of the vertex of a parabola that goes
    through point x and its two neighbors.
    Example:
    Defining a vector f with a local maximum at index 3 (= 6), find local
    maximum if points 2, 3, and 4 actually defined a parabola.
    In [3]: f = [2, 3, 1, 6, 4, 2, 3, 1]
    In [4]: parabolic(f, argmax(f))
    Out[4]: (3.2142857142857144, 6.1607142857142856)
    """
    xv = 1/2. * (f[x-1] - f[x+1]) / (f[x-1] - 2 * f[x] + f[x+1]) + x
    yv = f[x] - 1/4. * (f[x-1] - f[x+1]) * (xv - x)
    return (xv, yv)


def parabolic_polyfit(f, x, n):
    """Use the built-in polyfit() function to find the peak of a parabola
    f is a vector and x is an index for that vector.
    n is the number of samples of the curve used to fit the parabola.
    """
    a, b, c = polyfit(arange(x-n//2, x+n//2+1), f[x-n//2:x+n//2+1], 2)
    xv = -0.5 * b/a
    yv = a * xv**2 + b * xv + c
    return (xv, yv)

if __name__ == "__main__":
    female = []
    male = []
    path = ["data/american", 'data/australian', 'data/bangla', 'data/british', 'data/indian', 'data/malayalam',
    'data/odiya', 'data/telugu', 'data/welsh']
    for i in path:
        for root, sub, files in os.walk(i):
            for f in files:
                if "wav" in (os.path.join(root,f)):
                    signal, fs =  sf.read(os.path.join(root,f))  # join path with filename
                    try:
                        if (len(signal[0])) != 0:
                            signal = signal.reshape(len(signal)*len(signal[0]), )
                    except:
                        signal = signal
                    freq = freq_from_HPS(signal, fs)
                    if freq >= 165:
                        female.append(freq)
                    else:
                        male.append(freq)
        
    label_f = range(len(female))
    label_m = range(len(male))
    print(len(female))
    print(len(male))
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    ax1.scatter(label_f, female, s=10, c='r', marker="s", label='female')
    ax1.scatter(label_m, male, s=10, c='b', marker="o", label='male')
    leg = ax1.legend()
    ax1.legend(loc='upper right', frameon=False)
    plt.xlabel("Speech file number")
    plt.ylabel("Pitch - Hz")
    plt.show()

    # pitch_f = []
    # label_f = []
    # pitch_m = []
    # label_m = []
    # predict_f = []
    # predict_m = []
    # path = "gender/"
    # files = os.listdir(path)
    # for file in glob.glob(os.path.join(path, '*.wav')):
    #             signal, fs =  sf.read(file)
    #             pitches = freq_from_HPS(signal, fs)
    #             if "f" in file:
    #                     label_f.append(1)
    #                     pitch_f.append(pitches)
    #             if "m" in file:
    #                     label_m.append(2)
    #                     pitch_m.append(pitches)
    #             if pitches >= 165:
    #                     predict_f.append(1)
    #             else:
    #                     predict_m.append(2)
    # print(len(label_f))
    # print(len(label_m))
    # print(len(predict_f))
    # print(len(predict_m))