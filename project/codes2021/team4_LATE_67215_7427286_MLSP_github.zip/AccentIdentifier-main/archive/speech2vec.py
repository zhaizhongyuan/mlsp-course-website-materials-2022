import os
from typing import Tuple, Optional

import librosa
import numpy as np
from python_speech_features import mfcc
from tqdm import tqdm


def make_class_array(folder):
    lst = []
    files = os.listdir(folder)
    count_files = len(files)
    for file_path in tqdm(files):
        if '.DS_Store' in file_path:
            continue
        filename = os.path.join(folder, file_path)
        lst.append(make_normed_mfcc(filename))
    class_array = np.array(lst)
    class_array = np.reshape(class_array, (class_array.shape[0], class_array.shape[2], class_array.shape[1]))
    return class_array


def make_normed_mfcc(filename, outrate=8000):
    normed_sig = make_standard_length(filename)
    normed_mfcc_feat = mfcc(normed_sig, outrate)
    normed_mfcc_feat = normed_mfcc_feat.T
    return normed_mfcc_feat

def make_standard_length(filename, n_samps=40000):
    down_sig, rate = librosa_downsample(filename)
    normed_sig = librosa.util.fix_length(down_sig, samples)
    normed_sig = (normed_sig - np.mean(normed_sig)) / np.std(normed_sig)
    return normed_sig


def librosa_downsample(filename: str, /, sr: Optional[int] = 8000) -> Tuple[np.ndarray, int]:
    """
    Load an audio file with a custom sample rate.
    By default, the sample rate is 8000 Hz. If not specified, it would preserve the target file sample rate.

    :param filename: the location of the audio file to load
    :param sr: The specified sample rate. By default, it is 8000 Hz.
    :return y: audio time series
    :return s: sampling rate of the loaded audio time series
    """
    y, s = librosa.load(filename, sr=sr)
    return y, s


if __name__ == "__main__":
    folder = './data'
    speaker = 'speaker_01'

    for lan in os.listdir(folder):
        folder_path = os.path.join(folder, lan, speaker)
        if os.path.isdir(folder_path):
            print("Loading " + folder_path)
            x = make_class_array(folder_path)
            print(x.shape)
            X_file = './numpy-vectors/' + lan + '_' + speaker + '.files.npy'
            print("saving labels to ", X_file)
            # print(x)
            np.save(X_file, x)
