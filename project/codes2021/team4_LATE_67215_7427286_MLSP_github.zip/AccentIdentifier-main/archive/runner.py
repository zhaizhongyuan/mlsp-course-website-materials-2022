from typing import List, Dict

import numpy as np


def normalize(v: np.ndarray) -> np.ndarray:
    x, y = v.shape[1], v.shape[2]
    v = v.reshape((-1, x * y))
    nm = np.linalg.norm(v, axis=1)
    nm = nm.reshape((-1, 1))
    v = v / nm
    v = v.reshape((-1, x, y))
    return v


def get_data(accents: List[str], samples: Dict[str, np.ndarray]):
    x = np.zeros((0, 499, 13))
    y = []
    label = 0
    for accent in accents:
        y += (samples[accent].shape[0] * [label])
        x = np.concatenate((x, samples[accent]), axis=0)
        label += 1
    return x, y


if __name__ == "__main__":
    bangla = normalize(np.load("numpy-vectors/bangla_speaker_01.files.npy"))
    malayalam = normalize(np.load("numpy-vectors/malayalam_speaker_01.files.npy"))
    odiya = normalize(np.load("numpy-vectors/odiya_speaker_01.files.npy"))
    telugu = normalize(np.load("numpy-vectors/telugu_speaker_01.files.npy"))
    indian = normalize(np.load("numpy-vectors/indian_speaker_01.files.npy"))
    australian = normalize(np.load("numpy-vectors/australian_speaker_01.files.npy"))
    british = normalize(np.load("numpy-vectors/british_speaker_01.files.npy"))
    american = normalize(np.load("numpy-vectors/american_speaker_01.files.npy"))
    welsh = normalize(np.load("numpy-vectors/welsh_speaker_01.files.npy"))

    samples = {
        "bangla": bangla,
        "malayalam": malayalam,
        "odiya": odiya,
        "telugu": telugu,
        "indian": indian,
        "australian": australian,
        "british": british,
        "american": american,
        "welsh": welsh,
    }

    indian = ['bangla', 'malayalam', 'odiya', 'telugu', 'indian']
    non_indian = ["australian", "british", "american", "welsh"]
    x, y = get_data(non_indian, samples)
    print(x.shape)
    print(len(y))
