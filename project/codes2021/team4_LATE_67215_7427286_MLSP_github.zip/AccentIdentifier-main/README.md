# Accent Identifier
Recently, there has been significant progress in automatic speech recognition. Speaker accent identification has a huge impact on the automatic speech recognition system’s performance. By identifying English accents, we can build more robust systems that are inclusive of speaker variability. In our research, we explored multi-class English accent identification. We first proposed various feature engineering methods to improve the system performance. We then classified different accents using unsupervised Gaussian Mixture Models and Hidden Markov Models to do the classification. Lastly, we extended our research with gender classification using pitch estimation. For multi-class accent classification, with the best preprocessing and postprocessing combination, the model performance was 98.5% for GMM and 71.2% for HMM. With gender classification, the pitch estimation algorithm has achieved about 80% accuracy.

## Dataset
Download the `accentdb_extended` file from [AccentDB](https://accentdb.org) into an input directory (to be specified as an input path when calling the extract function in `save_file.py`).

We also have pre-generated dataset uploaded to [CMU Box](https://cmu.box.com/s/yzhk46299d3wv844y05pdme2x2e7fko0). Download the `Accent Identifier Raw Audio.zip` and extract its **content** to `data` folder, and Download the `Accent Identifier Dataset.zip` and extract its **content** to `data_output` folder. 

## Instructions
Create a virtual environment and install dependencies following the `requirements.txt`. Our project requires Python version 3.8 and upper. Run `save_file.py` first then run the necessary classification model. 

## File Structure
1. `feature_engineering` directory
* `extract.py`: This file exports a function that extracts features with specified parameters (I/O directory, preprocessing and postprocessing options, number of mfcc, etc)
* `presentation.ipynb`: Contains code that generates feature engineering legends in the final report and the video.
* `feature_engineering.ipynb`: Different feature engineering arguments experiment. This file contains experiments that explain how sample rate, preprocessing and postprocessing methods, and the number of MFCC features affect training accuracy on GMM.

2. `gender.py`
* This file estimates pitch using harmonic product spectrum. For each audio, if the pitch is greater than 165, it is classified as female and otherwise classified as male.
* Run it with `python3 gender.py`

3. `gmm.py`
* This file loads and splits data into train and test data, and then trains one Gaussian Mixture Model for each English accent with train data, and predicts results with test data. It also visualizes the test data with predicted labels with PCA, T-SNE, and UMAP.
* To run this file, first, run `python3 save_file.py` to save the `*.npy` files for each accent and then run `python3 gmm.py`


4. `hmm.py`
* This file loads and splits data into train and test data, and then trains one Hidden Markov model for each English accent with train data, and predicts results with test data. It also visualizes the test data with predicted labels with PCA, T-SNE, and UMAP.
* To run this file, first, run python3 save_file.py to save the `*.npy` files for each accent and then run `python3 hmm.py`

5. `pitch.py`
* This file is a different gender classification method used for the experiment. For the final classification, gender.py is used. It contains functions to visualize smoothed out frequencies which are used for the report.
* Run it with `python3 pitch.py`

6. `save_file.py`
* This file saves each accent to .npy files. It is run by other functions.
* Run it with `python3 save_file.py`

