import glob
import os

import librosa
import matplotlib.pylab as plt
import numpy


def extract_max(pitches,magnitudes, shape):
        new_pitches = []
        new_magnitudes = []
        for i in range(0, shape[1]):
                new_pitches.append(numpy.max(pitches[:,i]))
                new_magnitudes.append(numpy.max(magnitudes[:,i]))
        return (new_pitches,new_magnitudes)

def smooth(x,window_len=11,window='hanning'):
        if window_len<3:
                return x
        s=numpy.r_[2*x[0]-x[window_len-1::-1],x,2*x[-1]-x[-1:-window_len:-1]]
        if window == 'flat': #moving average
                w=numpy.ones(window_len,'d')
        else:
                w=eval('numpy.'+window+'(window_len)')
        y=numpy.convolve(w/w.sum(),s,mode='same')
        return y[window_len:-window_len+1]

def plot(vector, name, xlabel=None, ylabel=None):
        plt.figure()
        plt.plot(vector)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.plot()
        plt.show()

def set_variables(sample_f,duration,window_time,fmin,fmax,overlap):
        total_samples = sample_f * duration
        window_size = sample_f/1000 * window_time
        hop_length = total_samples / window_size
        needed_nb_windows = total_samples / (window_size - overlap)
        n_fft = needed_nb_windows * 2.0
        return total_samples, window_size, needed_nb_windows, n_fft, hop_length

def analyse(y,sr,n_fft,hop_length,fmin,fmax):
        pitches, magnitudes = librosa.core.piptrack(y=y, sr=sr, S=None, n_fft= n_fft, hop_length=hop_length, fmin=fmin, fmax=fmax, threshold=0.75)
        shape = numpy.shape(pitches)
        nb_samples = shape[0]
        nb_windows = shape[1]
        pitches, magnitudes = extract_max(pitches, magnitudes, shape)
        pitches = smooth(pitches,window_len=40)
        return (numpy.mean(pitches))
        # pitches1 = smooth(pitches,window_len=10)
        # pitches2 = smooth(pitches,window_len=20)
        # pitches3 = smooth(pitches,window_len=30)
        # pitches4 = smooth(pitches,window_len=40)

        # plot(pitches1, 'pitches1')
        # plot(pitches2, 'pitches2')
        # plot(pitches3, 'pitches3')
        # plot(pitches4, 'pitches4')
        # plot(magnitudes, 'magnitudes')
        # plot( y, 'audio')

if __name__ == "__main__":
        sample_f = 16000
        duration = 10
        window_time = 60
        fmin = 80
        fmax = 250
        overlap = 20
        total_samples, window_size, needed_nb_windows, n_fft, hop_length = set_variables(sample_f, duration, window_time, fmin, fmax, overlap)
        n_fft=2048
        y, sr = librosa.load('gender/f0001_us_f0001_00420.wav', sr=sample_f, duration=duration)
        n_fft = int(n_fft)
        hop_length = int(hop_length)
        # analyse(y, sr, n_fft, hop_length, fmin, fmax)
        pitch_f = []
        label_f = []
        pitch_m = []
        label_m = []
        predict_f = []
        predict_m = []
        path = "gender/"
        files = os.listdir(path)
        for file in glob.glob(os.path.join(path, '*.wav')):
                y, sr = librosa.load(file, sr=sample_f, duration=duration)
                n_fft = int(n_fft)
                hop_length = int(hop_length)
                pitches = analyse(y, sr, n_fft, hop_length, fmin, fmax)
                if "f" in file:
                        label_f.append(1)
                        pitch_f.append(pitches)
                if "m" in file:
                        label_m.append(2)
                        pitch_m.append(pitches)
                if pitches >= 165:
                        predict_f.append(1)
                else:
                        predict_m.append(2)
        print(len(label_f))
        print(len(label_m))
        print(len(predict_f))
        print(len(predict_m))
        # label_f = range(len(pitch_f))
        # label_m = range(len(pitch_m))
        # fig = plt.figure()
        # ax1 = fig.add_subplot(111)
        # ax1.scatter(label_f, pitch_f, s=10, c='r', marker="s", label='female')
        # ax1.scatter(label_m, pitch_m, s=10, c='b', marker="o", label='male')
        # plt.show()
