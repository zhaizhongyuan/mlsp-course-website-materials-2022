import os
import warnings
from typing import Literal, Optional

import librosa
import numpy as np
from python_speech_features import mfcc

PreprocessingType = Literal['trim-silence', 'trim-silence-fix-length', 'fix-length']
preprocessing_names = ['trim-silence', 'trim-silence-fix-length', 'fix-length']
PostprocessingType = Literal['take-average', 'flatten']
postprocessing_names = ['take-average', 'flatten']


def extract_training_features(file_in: str, /,
                              file_out: Optional[str] = None,
                              num_mfcc_features: int = 13,  # 3, 5, 7, 9, 11, 13, 15, 17, 19
                              sample_rate: int = 8000,  # 8000 and 16000
                              normalization: bool = False,  # Not considering at this time. Put this in future works
                              preprocessing: PreprocessingType = 'trim-silence',  # Try all
                              postprocessing: PostprocessingType = 'take-average',  # Try all
                              length: Optional[int] = None) -> np.ndarray:
    """
    Generate a dataset from audio file(s), with customizable options.

    :param file_in: The path to the audio file or the directory containing audio files.
        Either way, a matrix (2D) is yielded instead of a vector (1D).
    :param file_out: Optional NumPy array output path.
        If provided and valid, the dataset would be saved to a NumPy array data file.
    :param num_mfcc_features: Number of MFCC features to feature_engineering. 13 by default.
    :param sample_rate: Audio reading sample rate. 8000 Hz by default.
    :param normalization:
    :param preprocessing:
    :param postprocessing:
    :param length:
    :return: the generated audio feature dataset.
    """

    # Sanity check on values
    if not (os.path.isdir(file_in) or os.path.isfile(file_in)):
        raise ValueError(f'{file_in} is neither a directory nor file.')
    if num_mfcc_features < 1:
        raise ValueError(f'Number of MFCC features should be a positive integer, but yours is {num_mfcc_features}.')
    if sample_rate <= 0:
        raise ValueError(f'Sample rate should be positive, but yours is {sample_rate}.')
    if length is not None and length < 0:
        raise ValueError(f'Audio length must be positive, but yours is {length}.')
    if preprocessing == 'trim-silence' and postprocessing != 'take-average':
        raise ValueError('Preprocessing method "trim-silence" can only accept postprocessing method "take-average"')
    if 'fix-length' in preprocessing and length is None:
        raise ValueError('To fix length, a length value must be provided.')

    # Generate all input file names
    filenames = [os.path.join(file_in, filename) for filename in os.listdir(file_in)] \
        if os.path.isdir(file_in) else [file_in]

    def filter_non_wave(filename: str):
        _, ext = os.path.splitext(filename)
        return ext != 'wav'

    filenames = list(filter(filter_non_wave, filenames))

    # Read all audio data
    audio_data = [librosa.load(filename, sr=sample_rate)[0] for filename in filenames]
    del filenames

    # Normalization
    if normalization:
        audio_data = [(data - np.mean(data)) / np.std(data) for data in audio_data]

    # Preprocessing - trimming:
    if 'trim-silence' in preprocessing:
        audio_data = [librosa.effects.trim(data)[0] for data in audio_data]

    # Preprocessing - fixing length:
    if 'fix-length' in preprocessing :
        audio_data = [librosa.util.fix_length(data, length * sample_rate) for data in audio_data]

    # Generate MFCC features
    mfcc_data = [mfcc(data, sample_rate, numcep=num_mfcc_features) for data in audio_data]
    del audio_data

    # Postprocessing
    if preprocessing == 'trim-silence' or postprocessing == 'take-average':
        mfcc_data = np.array([np.mean(data, axis=0) for data in mfcc_data])
    else:
        mfcc_data = np.array([data.flatten() for data in mfcc_data], dtype=float)

    if file_out is not None:
        try:
            np.save(file_out, mfcc_data)
        except (FileNotFoundError, FileExistsError):
            warnings.warn(f'File output directory {file_out} failed. '
                          f'File saving is skipped.', RuntimeWarning)

    return mfcc_data
