from .extract import extract_training_features

extract = extract_training_features
