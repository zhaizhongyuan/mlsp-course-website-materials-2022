import warnings

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import umap.umap_ as umap
from hmmlearn import hmm
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore")
# train hmm

def train(am_train, in_train, au_train, ba_train, br_train, ma_train, od_train, te_train, we_train):
    am_hmm = hmm.GaussianHMM(n_components=13)
    in_hmm = hmm.GaussianHMM(n_components=13)
    au_hmm = hmm.GaussianHMM(n_components=13)
    ba_hmm = hmm.GaussianHMM(n_components=13)
    br_hmm = hmm.GaussianHMM(n_components=13)
    ma_hmm = hmm.GaussianHMM(n_components=13)
    od_hmm = hmm.GaussianHMM(n_components=13)
    te_hmm = hmm.GaussianHMM(n_components=13)
    we_hmm = hmm.GaussianHMM(n_components=13)

    am_hmm.fit(am_train)
    in_hmm.fit(in_train)
    au_hmm.fit(au_train)
    ba_hmm.fit(ba_train)
    br_hmm.fit(br_train)
    ma_hmm.fit(ma_train)
    od_hmm.fit(od_train)
    te_hmm.fit(te_train)
    we_hmm.fit(we_train)

    return am_hmm, in_hmm, au_hmm, ba_hmm, br_hmm, ma_hmm, od_hmm, te_hmm, we_hmm



def classification(am_test, in_test, au_test, ba_test, br_test, ma_test, od_test, te_test, we_test, am_hmm, in_hmm, au_hmm, ba_hmm, br_hmm, ma_hmm, od_hmm, te_hmm, we_hmm):
    files = [am_test, au_test, ba_test, br_test, in_test, ma_test, od_test, te_test, we_test]
    label = ["american", "australian", "bangla", "british", "indian", "malayalam", "odiya", "telugu", "welsh"]
    total_sample = 0
    error = 0
    count = 0
    test_result = []
    for file in files:
        for i in file:
            total_sample += 1
            winner = identify_accent(i.reshape(1, 13), am_hmm, in_hmm, au_hmm, ba_hmm, br_hmm, ma_hmm, od_hmm, te_hmm, we_hmm)
            expected_accent = label[count]
            test_result.append(label.index(winner))
            if winner != expected_accent: error += 1
        count = count + 1

    accuracy = (float(total_sample - error) / float(total_sample)) * 100
    accuracy_msg = "*** Accuracy = " + str(round(accuracy, 3)) + "% ***"
    print(accuracy_msg)

    return test_result


def identify_accent(vector, am_hmm, in_hmm, au_hmm, ba_hmm, br_hmm, ma_hmm, od_hmm, te_hmm, we_hmm):

    is_american_score = np.array(am_hmm.score(vector))

    is_australian_score = np.array(au_hmm.score(vector))

    is_bangla_score = np.array(ba_hmm.score(vector))

    is_british_score = np.array(br_hmm.score(vector))

    is_indian_scores = np.array(in_hmm.score(vector))

    is_malayalam_scores = np.array(ma_hmm.score(vector))

    is_odiya_scores = np.array(od_hmm.score(vector))

    is_telugu_scores = np.array(te_hmm.score(vector))

    is_welsh_scores = np.array(we_hmm.score(vector))

    accent_list = np.array([[is_american_score], [is_australian_score], [is_bangla_score],
                            [is_british_score], [is_indian_scores], [is_malayalam_scores],
                            [is_odiya_scores],
                            [is_telugu_scores], [is_welsh_scores]])
    winner_index = np.argmax(accent_list)

    if winner_index == 0:
        winner = "american"
    elif winner_index == 1:
        winner = "australian"
    elif winner_index == 2:
        winner = "bangla"
    elif winner_index == 3:
        winner = "british"
    elif winner_index == 4:
        winner = "indian"
    elif winner_index == 5:
        winner = "malayalam"
    elif winner_index == 6:
        winner = "odiya"
    elif winner_index == 7:
        winner = "telugu"
    elif winner_index == 8:
        winner = "welsh"
    return winner

def visualization(X, Y):
    pca = PCA(n_components=2)
    projected = pca.fit_transform(X)
    plt.scatter(projected[:, 0], projected[:, 1],
            c=Y, edgecolor='none', alpha=0.5,
            cmap=plt.cm.get_cmap('Spectral', 9))
    plt.title("PCA in 2D")
    plt.colorbar()
    plt.show()

    pca = PCA(n_components=3)
    projected = pca.fit_transform(X)
    plt.scatter(projected[:, 0], projected[:, 1], projected[:, 2],
            c=Y, edgecolor='none', alpha=0.5,
            cmap=plt.cm.get_cmap('Spectral', 9))
    plt.title("PCA in 3D")
    plt.colorbar()
    plt.show()

    reducer = umap.UMAP(n_neighbors = 20, n_components=2)
    reducer.fit(X)
    embedding = reducer.transform(X)
    plt.scatter(embedding[:, 0], embedding[:, 1], c=Y, cmap='Spectral', s=5)
    plt.gca().set_aspect('equal', 'datalim')
    plt.colorbar()
    plt.title("UMAP with 20 neighbours")
    plt.show()

    reducer = umap.UMAP(n_neighbors = 50, n_components=2)
    reducer.fit(X)
    embedding = reducer.transform(X)
    plt.scatter(embedding[:, 0], embedding[:, 1], c=Y, cmap='Spectral', s=5)
    plt.gca().set_aspect('equal', 'datalim')
    plt.colorbar()
    plt.title("UMAP with 50 neighbours")
    plt.show()

    tsne = TSNE(n_components=2,  perplexity=40, learning_rate=10, n_iter=1600)
    z = tsne.fit_transform(X)
    df = pd.DataFrame()
    df["y"] = Y
    df["comp-1"] = z[:,0]
    df["comp-2"] = z[:,1]
    sns.set_context("notebook", font_scale=1.1)
    sns.set_style("ticks")

    sns.scatterplot(x="comp-1", y="comp-2", hue=df.y.tolist(),
                    palette=sns.color_palette("hls", 9),
                    data=df).set(title="T-SNE projection")
    plt.show()


if __name__== "__main__":
    american_data = np.load('data_mfcc/american_accent_data.npy')
    australian_data = np.load('data_mfcc/australian_accent_data.npy')
    bangla_data = np.load('data_mfcc/bangla_accent_data.npy')
    british_data = np.load('data_mfcc/british_accent_data.npy')
    indian_data = np.load('data_mfcc/indian_accent_data.npy')
    malayalam_data = np.load('data_mfcc/malayalam_accent_data.npy')
    odiya_data = np.load('data_mfcc/odiya_accent_data.npy')
    telugu_data = np.load('data_mfcc/telugu_accent_data.npy')
    welsh_data = np.load('data_mfcc/welsh_accent_data.npy')

    american_label = np.load('data_mfcc/american_accent_label.npy')
    australian_label = np.load('data_mfcc/australian_accent_label.npy')
    bangla_label = np.load('data_mfcc/bangla_accent_label.npy')
    british_label = np.load('data_mfcc/british_accent_label.npy')
    indian_label = np.load('data_mfcc/indian_accent_label.npy')
    malayalam_label = np.load('data_mfcc/malayalam_accent_label.npy')
    odiya_label = np.load('data_mfcc/odiya_accent_label.npy')
    telugu_label = np.load('data_mfcc/telugu_accent_label.npy')
    welsh_label = np.load('data_mfcc/welsh_accent_label.npy')

    am_train, am_test, y_am_train, y_am_test = train_test_split(american_data, american_label, test_size=0.2,
                                                                    shuffle=True)
    in_train, in_test, y_in_train, y_in_test = train_test_split(indian_data, indian_label, test_size=0.2, shuffle=True)
    au_train, au_test, y_au_train, y_au_test = train_test_split(australian_data, australian_label, test_size=0.2,
                                                                    shuffle=True)
    ba_train, ba_test, y_ba_train, y_ba_test = train_test_split(bangla_data, bangla_label, test_size=0.2, shuffle=True)
    br_train, br_test, y_br_train, y_br_test = train_test_split(british_data, british_label, test_size=0.2,
                                                                    shuffle=True)
    ma_train, ma_test, y_ma_train, y_ma_test = train_test_split(malayalam_data, malayalam_label, test_size=0.2,
                                                                    shuffle=True)
    od_train, od_test, y_od_train, y_od_test = train_test_split(odiya_data, odiya_label, test_size=0.2, shuffle=True)
    te_train, te_test, y_te_train, y_te_test = train_test_split(telugu_data, telugu_label, test_size=0.2, shuffle=True)
    we_train, we_test, y_we_train, y_we_test = train_test_split(welsh_data, welsh_label, test_size=0.2, shuffle=True)

    test_data = np.vstack((am_test, au_test, ba_test, br_test, in_test, ma_test, od_test, te_test, we_test))
    test_true_label = np.hstack((y_am_test, y_au_test, y_ba_test, y_br_test, y_in_test, y_ma_test, y_od_test, y_te_test, y_we_test))

    am_hmm, in_hmm, au_hmm, ba_hmm, br_hmm, ma_hmm, od_hmm, te_hmm, we_hmm = train(am_train, in_train, au_train, ba_train, br_train, ma_train, od_train, te_train, we_train)
    test_result = classification(am_test, in_test, au_test, ba_test, br_test, ma_test, od_test, te_test, we_test, am_hmm, in_hmm, au_hmm, ba_hmm, br_hmm, ma_hmm, od_hmm, te_hmm, we_hmm)

    visualization(test_data, test_result)
    # visualization(test_data, test_true_label)
