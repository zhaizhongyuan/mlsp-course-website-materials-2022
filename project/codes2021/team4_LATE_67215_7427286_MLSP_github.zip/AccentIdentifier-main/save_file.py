import os
from threading import Thread

from feature_engineering.extract import extract_training_features, preprocessing_names, postprocessing_names

american_path = './data/american'
australian_path = './data/australian'
british_path = './data/british'
welsh_path = './data/welsh'
indian_path = './data/indian'
bangla_path = './data/bangla'
odiya_path = './data/odiya'
telugu_path = './data/telugu'
malayalam_path = './data/malayalam'

all_path = [american_path, australian_path, british_path, welsh_path, indian_path,
            bangla_path, odiya_path, telugu_path, malayalam_path]


def first_work(in_dir: str):
    accent = in_dir.split('/')[-1]
    for d in os.listdir(in_dir):  # speaker_01, speaker_02, etc.
        read_dir = os.path.join(in_dir, d)
        if not os.path.isdir(read_dir):
            continue
        for sr in [8000, 16000]:
            for pre in preprocessing_names:
                for post in postprocessing_names:
                    # This combination is not valid
                    if pre == 'trim-silence' and post == 'flatten':
                        continue

                    if pre == 'trim-silence':
                        length = None
                    elif pre == 'trim-silence-fix-length':
                        length = 2
                    else:
                        length = 7

                    output_dir = os.path.join('./data_output', f'{sr}_{pre}_{post}', accent, d)
                    os.makedirs(output_dir, exist_ok=True)
                    extract_training_features(read_dir,
                                              file_out=f'{output_dir}/data.npy',
                                              sample_rate=sr,
                                              preprocessing=pre,
                                              postprocessing=post,
                                              length=length)


def second_work(in_dir: str):
    accent = in_dir.split('/')[-1]
    for speaker in os.listdir(in_dir):  # speaker_01, speaker_02, etc.
        read_dir = os.path.join(in_dir, speaker)
        if not os.path.isdir(read_dir):
            continue
        for num_mfcc in range(3, 24, 2):
            print(f'Working on {accent} accent with {num_mfcc} MFCC.')

            second_output_dir = os.path.join('./data_output', f'{num_mfcc}_trim-silence_take-average', accent, speaker)
            os.makedirs(second_output_dir, exist_ok=True)
            extract_training_features(read_dir,
                                      file_out=f'{second_output_dir}/data.npy',
                                      num_mfcc_features=num_mfcc,
                                      sample_rate=8000, preprocessing='trim-silence', postprocessing='take-average',
                                      length=7)


def main():
    threads = [Thread(target=second_work, args=[path]) for path in all_path] + \
        [Thread(target=first_work, args=[path for path in all_path])]
    for i, t in enumerate(threads):
        t.start()
    for i, t in enumerate(threads):
        t.join()


if __name__ == '__main__':
    main()
