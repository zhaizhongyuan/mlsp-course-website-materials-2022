import torch
import numpy as np
import os




length=2

lookup = torch.load('Training_Set.pkl')
folders = os.listdir('./Training_Set')
counted_labels = 0
all_data = []
for folder in folders:
    for file in os.listdir('./Training_Set/' + folder):
        if 'wav' in file:
            audio_name = './Training_Set/%s/%s'%(folder, file)
            spectrogram, csv_name, num_seconds = lookup[audio_name]
            num_vector = spectrogram.shape[1]
            labels = open(csv_name).readlines()[1:]
            num_labels = len(labels[0].strip().split(',')) - 3
            for record in labels:
                data = record.strip().split(',')
                if 'POS' in data:
                    label = data[-num_labels:].index('POS') + counted_labels
                    start, end = float(data[1]), float(data[2])
                    start = int(start / num_seconds * num_vector)
                    end = int(end / num_seconds * num_vector) + 1
                    feature = spectrogram[:, start:end]
                    h = feature.shape[1]
                    if length == 1 or h == 1:
                        feature = np.concatenate(
                            [feature.mean(1),
                             feature.mean(1)
                            ])
                    else:
                        feature = np.concatenate(
                            [feature[:,:h//2].mean(1),
                             feature[:,h//2:].mean(1)
                            ])
                    all_data.append((feature, label))
                elif 'UNK' not in data:
                    start, end = float(data[1]), float(data[2])
                    start = int(start / num_seconds * num_vector)
                    end = int(end / num_seconds * num_vector) + 1
                    feature = spectrogram[:, start:end]
                    h = feature.shape[1]
                    if length == 1 or h == 1:
                        feature = np.concatenate(
                            [feature.mean(1),
                             feature.mean(1)
                            ])
                    else:
                        feature = np.concatenate(
                            [feature[:,:h//2].mean(1),
                             feature[:,h//2:].mean(1)
                            ])
                    all_data.append((feature, -1))

X = [i[0] for i in all_data]
Y = [i[1] for i in all_data]
X, Y = np.array(X), np.array(Y) + 1
np.save('%s_X.npy'%dataset, X)
np.save('%s_Y.npy'%dataset, Y)


