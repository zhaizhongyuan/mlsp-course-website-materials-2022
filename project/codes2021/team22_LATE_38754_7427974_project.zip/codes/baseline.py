import numpy as np
from sklearn import metrics
import torch

data = torch.load('Validation_Feature.pkl')


tol_auc = count = 0.0
whiten = True
for file in data:
    for repeat in range(10):
        X, Y = data[file]
        index = np.arange(X.shape[0])
        np.random.shuffle(index)
        X, Y = X[index], Y[index]
        support = np.where(Y==1)[0][:5]
        test = [i for i in range(X.shape[0]) if i not in support]
        givenX = np.array([X[i] for i in support])
        testX = np.array([X[i] for i in test])
        testY = np.array([Y[i] for i in test])

        center = givenX.mean(0,keepdims=True)
        distence = (testX - center)
        if whiten == True:
            center_givenX = givenX - center
            Cov = center_givenX.T @ center_givenX / center_givenX.shape[0]
            Cov += np.eye(center_givenX.shape[1])
            invCov = np.linalg.inv(Cov)
            prob = np.array([-i@(invCov@i) for i in distence])
        else:
            prob = [-i@i for i in distence]

        prob = (prob - prob.min()) / (prob.max() - prob.min())
        fpr, tpr, thresholds = metrics.roc_curve(testY, prob)
        auc = metrics.auc(fpr, tpr)
        tol_auc += auc
        count += 1


print(tol_auc/count)