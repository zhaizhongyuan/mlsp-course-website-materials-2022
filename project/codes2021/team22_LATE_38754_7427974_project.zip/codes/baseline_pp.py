import numpy as np
from sklearn import metrics

method = 'cca'
# method = 'xgboost'
trainX, trainY = torch.load('baseline_pp_%s_train.pkl'%method)


all_labels = set(list(trainY))
num_labels = len(all_labels)
categary_mean = [trainX[trainY==i].mean(0) for i in all_labels]
mu_categary_mean = sum(categary_mean) / num_labels
Sigma0 = np.diag(np.array(categary_mean).var(0))

categary_cov = []
for idx, label in enumerate(all_labels):
    features = trainX[trainY==label]
    features -= categary_mean.reshape(-1,1)
    Cov = features.T @ features / features.shape[0]
    categary_cov.append(Cov)

tol_auc = count = 0.0
data = torch.load('baseline_pp_%s_val.pkl'%method)
for file in data:
    for repeat in range(10):
        X, Y = data[file]
        index = np.arange(X.shape[0])
        np.random.shuffle(index)
        X, Y = X[index], Y[index]
        support = np.where(Y==1)[0][:5]
        test = [i for i in range(X.shape[0]) if i not in support]
        givenX = np.array([X[i] for i in support])
        testX = np.array([X[i] for i in test])
        testY = np.array([Y[i] for i in test])

        center = givenX.mean(0,keepdims=True)
        center_givenX = givenX - center
        Cov = center_givenX.T @ center_givenX / center_givenX.shape[0]

        similarity = [(center-i)@(center-i) for i in categary_mean]
        threshold = sorted(similarity)[-6]
        similar_Cov = [categary_cov[i] for i in range(num_labels) if similarity[i]>threshold]
        Cov = (Cov + sum(similar_Cov)) / (1 + len(similar_Cov))
        Cov += np.eye(center_givenX.shape[1]) * np.linalg.eigvals(Cov).real.max()
        invCov = np.linalg.inv(Cov)

        mu = np.linalg.pinv(5 * Sigma0 + Cov) @ (Cov @ mu_categary_mean + 5 * Sigma0 @ center)

        distence = testX - mu.reshape(-1,1)
        prob = np.array([-i@(invCov@i) for i in distence])

        prob = (prob - prob.min()) / (prob.max() - prob.min())
        fpr, tpr, thresholds = metrics.roc_curve(testY, prob)
        auc = metrics.auc(fpr, tpr)
        tol_auc += auc
        count += 1


print(tol_auc/count)