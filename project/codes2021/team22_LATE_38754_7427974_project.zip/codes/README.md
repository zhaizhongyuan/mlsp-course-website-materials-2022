Codes for MLSP project Few-shot Bioacoustic Event Detection

Require torch, librosa, sklearn and xgboost.


Download data from the challenge website. Extract files and put the codes in the root folder of the data.
First run save_spectrogram.py to get the spectrogram of train and val audios.
Second run generate_train_feature.py and generate_val_feature.py to get the features for each short duration.
We can run these models beginning with baseline to get the results.
To run baseline_pp.py you need to run baseline_plus_CCA.py/baseline_plus_xgboost.py first.