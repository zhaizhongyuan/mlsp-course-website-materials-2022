import librosa
import torch
import os



def save_spectrogram(dataset='Training_Set'):
    lookup = {}
    folders = os.listdir('./%s'%dataset)
    for folder in folders:
        for file in os.listdir('./%s/'%dataset + folder):
            if 'wav' in file:
                audio_name = './%s/%s/%s'%(dataset, folder, file)
                csv_name = audio_name.replace('wav','csv')
                audio, sr = librosa.load(audio_name)
                num_seconds = audio.shape[0] / sr
                spectrogram = librosa.stft(audio, n_fft=sr//10)
                spectrogram = abs(spectrogram)
                lookup[audio_name] = [spectrogram, csv_name, num_seconds]
    torch.save(lookup, '%s.pkl'%dataset)
    return

if __name__ == '__main__':
    save_spectrogram('Training_Set')
    save_spectrogram('Validation_Set')
