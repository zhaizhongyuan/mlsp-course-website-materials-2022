import torch
import numpy as np
import os

lookup = torch.load('Validation_Set.pkl')
folders = os.listdir('./Validation_Set')

data_lookup = {}

for folder in folders:
    for file in os.listdir('./Validation_Set/' + folder):
        if 'wav' in file:
            all_data = []
            audio_name = './Validation_Set/%s/%s'%(folder, file)
            spectrogram, csv_name, num_seconds = lookup[audio_name]
            num_vector = spectrogram.shape[1]
            labels = open(csv_name).readlines()[1:]
            for record in labels:
                data = record.strip().split(',')
                label = int('POS' in data)
                start, end = float(data[1]), float(data[2])
                start = int(start / num_seconds * num_vector)
                end = int(end / num_seconds * num_vector) + 1
                feature = spectrogram[:, start:end]
                h = feature.shape[1]
                if h == 1:
                    feature = np.concatenate(
                        [feature.mean(1),
                         feature.mean(1)
                        ])
                else:
                    feature = np.concatenate(
                        [feature[:,:h//2].mean(1),
                         feature[:,h//2:].mean(1)
                        ])
                all_data.append((feature, label))
            X = [i[0] for i in all_data]
            Y = [i[1] for i in all_data]
            X, Y = np.array(X), np.array(Y)
            data_lookup[audio_name] = (X,Y)



torch.save(data_lookup, 'Validation_Feature.pkl')