import numpy as np
from xgboost.sklearn import XGBClassifier


def xgboost_search(dataset='Training_Set'):
    X, Y = np.load('%s_X.npy'%dataset), np.load('%s_Y.npy'%dataset)
    index = np.arange(len(Y))
    num_train = len(Y) * 5 // 6
    best_acc = 0.0
    for n_estimators in [80,100,150]:
        for max_depth in [5,6,8, 10]:
            acc = 0.0
            for run in range(8):
                xgboost_clf = XGBClassifier(base_score=0.5, booster='gbtree', colsample_bylevel=1,
                              colsample_bynode=1, colsample_bytree=1, gamma=0,
                              learning_rate=0.1, max_delta_step=0, max_depth=max_depth,
                              min_child_weight=1, n_estimators=n_estimators, n_jobs=16,
                              nthread=None, num_class=max(Y)+1, objective='multi:softmax',
                              random_state=0, reg_alpha=20, reg_lambda=10,
                              seed=None, silent=None, subsample=0.9, verbosity=1,
                              eval_metric='mlogloss')
                np.random.shuffle(index)
                xgboost_clf = xgboost_clf.fit(X[index[:num_train]], Y[index[:num_train]])
  
                acc_0 = (xgboost_clf.predict(X[index[num_train:]]) == Y[index[num_train:]]).mean()
                acc += acc_0
                del xgboost_clf
            if acc > best_acc:
                best_acc = acc
                configs = (n_estimators, max_depth)

    xgboost_clf = XGBClassifier(base_score=0.5, booster='gbtree', colsample_bylevel=1,
                              colsample_bynode=1, colsample_bytree=1, gamma=0,
                              learning_rate=0.1, max_delta_step=0, max_depth=configs[0],
                              min_child_weight=1, n_estimators=configs[1], n_jobs=16,
                              nthread=None, num_class=max(Y)+1, objective='multi:softmax',
                              random_state=0, reg_alpha=20, reg_lambda=10,
                              seed=None, silent=None, subsample=0.9, verbosity=1,
                              eval_metric='mlogloss')
    xgboost_clf.fit(X,Y)
    newX = np.log(xgboost_clf.predict_prob(X))
    X = np.hstack([X, newX])
    torch.save([X,Y], 'baseline_pp_xgboost_train.pkl')
    return xgboost_clf

data = torch.load('Validation_Feature.pkl')
xgboost_clf = xgboost_search()
for file in data:
    X, Y = data[file]
    newX = np.log(xgboost_clf.predict_prob(X))
    X = np.hstack([X, newX])
    data[file] = (X,Y)

torch.save(data, 'baseline_pp_xgboost_val.pkl')

tol_auc = count = 0.0
for file in data:
    for repeat in range(10):
        X, Y = data[file]
        index = np.arange(X.shape[0])
        np.random.shuffle(index)
        X, Y = X[index], Y[index]
        support = np.where(Y==1)[0][:5]
        test = [i for i in range(X.shape[0]) if i not in support]
        givenX = np.array([X[i] for i in support])
        testX = np.array([X[i] for i in test])
        testY = np.array([Y[i] for i in test])

        center = givenX.mean(0,keepdims=True)
        distence = (testX - center)
        center_givenX = givenX - center
        Cov = center_givenX.T @ center_givenX / center_givenX.shape[0]
        Cov += np.eye(center_givenX.shape[1])
        invCov = np.linalg.inv(Cov)
        prob = np.array([-i@(invCov@i) for i in distence])

        prob = (prob - prob.min()) / (prob.max() - prob.min())
        fpr, tpr, thresholds = metrics.roc_curve(testY, prob)
        auc = metrics.auc(fpr, tpr)
        tol_auc += auc
        count += 1


print(tol_auc/count)