# -*- coding: utf-8 -*-
"""
Script for ASV model training
Author: Yuan Tang
"""

! pip install spafe
! git clone https://github.com/stoneMo/ASVspoof.git
! pip install python_speech_features
! pip install scikit-learn==1.0.1
! git clone https://github.com/RaviSoji/plda.git
! pip install plda/

import gc
import os
import random
import numpy as np
import pandas as pd
from glob import glob
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, roc_curve
import librosa
from spafe.features.lfcc import lfcc
from python_speech_features import mfcc
import soundfile as sf
from joblib import dump, load
from google.colab import drive
drive.mount('/content/drive')
import sys
sys.path.insert(0,'/content/drive/My Drive/MLSP_project/CQCC')
import time
from cqcc import cqcc

save_dir = '/content/drive/My Drive/MLSP_project/checkpoints/'
data_dir = '/content/drive/My Drive/MLSP_project/data/'

# define metrics
def get_accuracy(target, pred):
    assert target.shape == pred.shape, "make sure target and prediction has the same shape"
    return np.sum(np.where(target == pred, 1, 0)) / len(target)

def get_auc(target, pred):
    return roc_auc_score(target, pred)

def get_eer(target, pred):
    fpr, tpr, threshold = roc_curve(target, pred, pos_label=1)
    fnr = 1 - tpr
    eer_threshold = threshold[np.nanargmin(np.absolute((fnr - fpr)))]
    eer = fpr[np.nanargmin(np.absolute((fnr - fpr)))]
    return eer, eer_threshold

# train models
def train(model, Xtrain, Ytrain, clf_name):
    if len(Xtrain.shape) != 2:
        Xtrain = np.reshape(Xtrain, (Xtrain.shape[0], Xtrain.shape[1] * Xtrain.shape[2]))
    
    clf = model

    if clf_name in glob(save_dir + '*'): 
        clf = load(clf_name)
        print('previous model loaded')
    else:
        print("starting training on %d training samples\n" % len(Ytrain))
        s = time.time()
        clf.fit(Xtrain, Ytrain)
        print("Training Completed! took %f" % (time.time() - s))
        dump(clf, clf_name) 
    

def test(model, Xtest, Ytest, clf_name):
    if len(Xtest.shape) != 2:
        Xtest = np.reshape(Xtest, (Xtest.shape[0], Xtest.shape[1] * Xtest.shape[2]))
    
    clf = model

    if clf_name in glob(save_dir + '*'): 
        clf = load(clf_name)
        print('previous model loaded')
    else:
        print("model checkpoint not found!")

    print("starting predicting SVM on %d testing samples\n" % len(Ytest))
    # Ypred = clf.predict(Xtest)
    print ('predict accuracy:', clf.score(Xtest, Ytest))
    s = time.time()
    Ypred = clf.decision_function(Xtest)
    print("Evaluation Completed! took %f" % (time.time() - s))
    acc = get_accuracy(Ytest, Ypred)
    auc = get_auc(Ytest, Ypred)
    eer, _ = get_eer(Ytest, Ypred)
    print("achieving %f acc and %f auc and %f eer. " % (acc, auc, eer))
    return Ypred

def train_test_gmm(Xtrain, Ytrain, Xtest, Ytest, n_components):
    from sklearn.mixture import GaussianMixture, BayesianGaussianMixture
    import time
    if len(Xtrain.shape) != 2:
        Xtrain = np.reshape(Xtrain, (Xtrain.shape[0], Xtrain.shape[1] * Xtrain.shape[2]))
    spoof = []
    spoof_label = 0
    genuine = []
    genuine_label = 1
    for i, data in enumerate(Ytrain):
        if data == 0:
            spoof.append(Xtrain[i])
        else:
            genuine.append(Xtrain[i])
    print("training compoennets", n_components)
    bon_path = save_dir + 'mfcc_gmmbon_100_' + str(n_components) + '.joblib'
    sp_path = save_dir + 'mfcc_gmmsp_100_' + str(n_components) + '.joblib'
    if bon_path in glob(save_dir + '*'):
        gmm_bon = load(bon_path)
        gmm_sp = load(sp_path)
        print("model loaded!")
        t0 = time.time()
        score_real = gmm_bon.score_samples(Xtest)
        print('Bon gmm evaled, time spend:', time.time() - t0)

        t0 = time.time()
        score_fake = gmm_sp.score_samples(Xtest)
        print('Sp gmm evaled, time spend:', time.time() - t0)
        Ypred = (score_real - score_fake)/ np.max(score_real - score_fake)
        acc = get_accuracy(Ytest, Ypred)
        auc = get_auc(Ytest, Ypred)
        eer, _ = get_eer(Ytest, Ypred)
        print("achieving %f acc and %f auc and %f eer. " % (acc, auc, eer))
        del gmm_sp
        del gmm_bon
        return score_real, score_fake
    else:
        gmm_bon = GaussianMixture(n_components = n_components, covariance_type='diag',n_init = 50) # min shape[0] = 135 # max = 1112
        # 2580 1112 337.8709302325581 289
        gmm_sp  = GaussianMixture(n_components = n_components, covariance_type='diag',n_init = 50)  # min shape[0] = 64  # max = 1318
        # 22800 1318 341.9821929824561 297

        Xbon = np.vstack(genuine)
        print('Bon feature stacked, shape as: ', Xbon.shape)
        Xsp = np.vstack(spoof)
        print('Sp feature stacked, shape as: ', Xsp.shape)

        t0 = time.time()
        gmm_bon.fit(Xbon)
        print('Bon gmm trained, time spend:', time.time() - t0)
        dump(gmm_bon, bon_path) 

        t0 = time.time()
        gmm_sp.fit(Xsp)
        print('Sp gmm trained, time spend:', time.time() - t0)
        dump(gmm_sp, sp_path) 

        t0 = time.time()
        score_real = gmm_bon.score_samples(Xtest)
        print('Bon gmm evaled, time spend:', time.time() - t0)

        t0 = time.time()
        score_fake = gmm_sp.score_samples(Xtest)
        print('Sp gmm evaled, time spend:', time.time() - t0)
    del gmm_sp
    del gmm_bon
    return score_real, score_fake

# load data
mode = 'mfcc'

Xtrain = np.load(data_dir + mode + '_Xtrain_50.npy', allow_pickle=True)
Ytrain = np.load(data_dir + 'Ytrain.npy')
Xval = np.load(data_dir + mode + '_Xval_50.npy', allow_pickle=True)
Yval = np.load(data_dir + 'Yval.npy')
Xtest = np.load(data_dir + mode + '_Xtest_50.npy')
Ytest = np.load(data_dir + 'Ytest.npy')

Xtrain, Ytrain = np.concatenate([Xtrain, Xval], axis=0), np.concatenate([Ytrain, Yval], axis=0)
Xtrain, Ytrain = sklearn.utils.shuffle(Xtrain, Ytrain)

print(Xtrain.shape, Xval.shape, Xtest.shape)
print('training set has %d samples, %d are genuine, %d are spoof\n' % (len(Xtrain), np.sum(Ytrain), len(Ytrain) - np.sum(Ytrain)))
print('validation set has %d samples, %d are genuine, %d are spoof\n' % (len(Xval), np.sum(Yval), len(Yval) - np.sum(Yval)))
print('test set has %d samples, %d are genuine, %d are spoof\n' % (len(Xtest), np.sum(Ytest), len(Ytest) - np.sum(Ytest)))

model_choice = 'gmm'
clf_name = save_dir + 'mfcc_gmm_100.joblib'

if len(Xtrain.shape) != 2:
        Xtrain = np.reshape(Xtrain, (Xtrain.shape[0], Xtrain.shape[1] * Xtrain.shape[2]))
if len(Xval.shape) != 2:
        Xval = np.reshape(Xval, (Xval.shape[0], Xval.shape[1] * Xval.shape[2]))
if len(Xtest.shape) != 2:
    Xtest = np.reshape(Xtest, (Xtest.shape[0], Xtest.shape[1] * Xtest.shape[2]))

if model_choice == 'svm':
    clf = sklearn.svm.SVC(verbose=True)
    train(clf, Xtrain, Ytrain, clf_name)
    test(clf, Xval, Yval, clf_name)
    pred = test(clf, Xtest, Ytest, clf_name)
elif model_choice == 'lda':
    from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
    clf = LinearDiscriminantAnalysis(n_components=1)
    train(clf, Xtrain, Ytrain, clf_name)
    test(clf, Xtest, Ytest, clf_name)
elif model_choice == 'gmm':
    pred_real, pred_fake = train_test_gmm(Xtrain, Ytrain, Xtest, Ytest, 32)
    # pred_real, pred_fake = train_test_gmm(Xtrain, Ytrain, Xtrain, Ytrain, 5)
elif model_choice == 'plda':
    import plda
    clf = plda.Classifier()
    clf.fit_model(Xtrain, Ytrain, n_principal_components=650)
    Ypred, log_p_predictions = clf.predict(Xtest)
    acc = get_accuracy(Ytest, Ypred)
    auc = get_auc(Ytest, Ypred)
    eer, _ = get_eer(Ytest, Ypred)
    # Ylog = np.max(log_p_predictions, axis=-1)
    # acc = get_accuracy(Ytest, Ylog)
    # auc = get_auc(Ytest, Ylog)
    # eer, _ = get_eer(Ytest, Ylog)
    print("achieving %f acc and %f auc and %f eer. " % (acc, auc, eer))
elif model_choice == 'pca_svm':
    from sklearn.decomposition import PCA, NMF, FastICA
    dim_reduce = PCA(n_components=100) # PCA
    dim_reduce.fit(Xtrain)
    Xtrain_100 = dim_reduce.transform(Xtrain)
    Xval_100 = dim_reduce.transform(Xval)
    Xtest_100 = dim_reduce.transform(Xtest)
    clf = sklearn.svm.SVC(verbose=True)
    train(clf, Xtrain_100, Ytrain, clf_name)
    test(clf, Xval_100, Yval, clf_name)
    test(clf, Xtest_100, Ytest, clf_name)
elif model_choice == 'ensemble':
    clf1 = sklearn.svm.SVC(verbose=True)
    clf2 = sklearn.svm.SVC(verbose=True)
    clf3 = sklearn.svm.SVC(verbose=True)
    train(clf1, Xtrain[:1500], Ytrain[:1500], save_dir + mode + '_ensemble_svm1.joblib')
    train(clf2, Xtrain[1500:3000], Ytrain[1500:3000], save_dir + mode + '_ensemble_svm2.joblib')
    train(clf3, Xtrain[3000:], Ytrain[3000:], save_dir + mode + '_ensemble_svm3.joblib')
    Ypred1 = test(clf1, Xtest, Ytest, save_dir + mode + '_ensemble_svm1.joblib')
    Ypred2 = test(clf2, Xtest, Ytest, save_dir + mode + '_ensemble_svm2.joblib')
    Ypred3 = test(clf3, Xtest, Ytest, save_dir + mode + '_ensemble_svm3.joblib')
    Ypred = (Ypred1 + Ypred2 + Ypred3)/3
    acc = get_accuracy(Ytest, Ypred)
    auc = get_auc(Ytest, Ypred)
    eer, _ = get_eer(Ytest, Ypred)
    print("ENSEMBLED - achieving %f acc and %f auc and %f eer. " % (acc, auc, eer))

pred = pred_real - pred_fake
auc = get_auc(Ytest, pred)
eer, eer_threshold = get_eer(Ytest, pred)
print(eer_threshold)
pred[pred<eer_threshold] = 0
pred[pred>eer_threshold] = 1
acc = get_accuracy(pred, Ytest)
print("achieving %f acc and %f auc and %f eer. " % (acc, auc, eer))