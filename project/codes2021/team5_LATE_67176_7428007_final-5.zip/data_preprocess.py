# -*- coding: utf-8 -*-
"""
Script for audio data preprocessing
Author: Yuan Tang
"""

! pip install spafe
! git clone https://github.com/stoneMo/ASVspoof.git
! pip install python_speech_features
! pip install scikit-learn==1.0.1

import gc
import os
import numpy as np
import pandas as pd
from glob import glob
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, roc_curve
import librosa
from spafe.features.lfcc import lfcc
from python_speech_features import mfcc
import soundfile as sf
from joblib import dump, load
from google.colab import drive
drive.mount('/content/drive')
import sys
sys.path.insert(0,'/content/drive/My Drive/MLSP_project/CQCC')
from cqcc import cqcc

train_dir = '/content/drive/My Drive/MLSP_project/ASVspoof2017_V2_train'
dev_dir = '/content/drive/My Drive/MLSP_project/ASVspoof2017_V2_dev'
eval_dir = '/content/drive/My Drive/MLSP_project/ASVspoof2017_V2_eval'
train_file = '/content/drive/My Drive/MLSP_project/protocol_V2/ASVspoof2017_V2_train.trn.txt'
dev_file = '/content/drive/My Drive/MLSP_project/protocol_V2/ASVspoof2017_V2_dev.trl.txt'
eval_file = '/content/drive/My Drive/MLSP_project/protocol_V2/ASVspoof2017_V2_eval.trl.txt'
save_dir = '/content/drive/My Drive/MLSP_project/checkpoints/'
data_dir = '/content/drive/My Drive/MLSP_project/data/'

def load_protocal(filename):
    mapping = {'genuine': 1, 'spoof': 0}
    audio, label = [], []
    with open(filename) as f:
        for line in f:
            audio.append(line.split(' ')[0])
            label.append(mapping[line.split(' ')[1]])
    return np.array(audio), np.array(label)

def get_cqcc_feat(audio, sr):
    audio = audio.reshape(audio.shape[0], 1)  # for one-channel signal 
    # print(audio.shape)

    # PARAMETERS
    B = 96
    fmax = sr/2
    fmin = fmax/2**9
    d = 16
    cf = 19
    ZsdD = 'ZsdD'

    # COMPUTE CQCC FEATURES
    CQcc, LogP_absCQT, TimeVec, FreqVec, Ures_LogP_absCQT, Ures_FreqVec, absCQT = cqcc(audio, sr, B, fmax, fmin, d, cf, ZsdD)
    # print("cqcc_feat:", CQcc.shape)       # number of frames * number of cep
    # print("cqcc_lpms:", LogP_absCQT.shape)   
    # plt.imsave("LogP_absCQT.T.png", LogP_absCQT.T)
    return CQcc, fmax, fmin

def load_audio(dir, file_list, mode='melspectrogram', length=200, sr=16000, nfft=8192):
    audio_list = []
    cqcc_list = []
    mfcc_list = []
    for i, entry in enumerate(file_list):
        if (i % 500) == 0:
            print("processing %d/%d" % (i, len(file_list)))
            
        filename = dir + '/' + entry
        # audio, sr = librosa.load(filename, sr=sr)
        audio, sr = sf.read(filename)
        if mode == 'stft':
            spec = librosa.stft(audio, n_fft=nfft, 
                    hop_length=256, center=False, win_length=2048)
        elif mode == 'melspectrogram':
            spec = librosa.feature.melspectrogram(audio, n_fft=nfft, 
                    hop_length=256, center=False, win_length=2048, sr=sr)
        elif mode == 'mfcc': # our baseline
            spec = librosa.feature.mfcc(audio, n_fft=nfft, 
                    hop_length=256, center=False, win_length=2048, sr=sr)
        elif mode == 'lfcc':
            spec = lfcc(sig=audio, nfft=nfft, fs=sr)
        elif mode == 'cqcc':
            feat_cqcc, fmax, fmin  = get_cqcc_feat(audio, sr)
            if i == 0:
                print("feat cqcc:", feat_cqcc.shape)
            numframes = feat_cqcc.shape[0]
            winstep = 0.005
            winlen =  (len(audio) - winstep * sr * (numframes-1))/sr
            if i == 0:
                print("winlen:", winlen)
            feat_mfcc = mfcc(audio, sr, winlen=winlen, winstep=winstep, lowfreq=fmin,highfreq=fmax) 
            feat_cqcc = librosa.util.fix_length(feat_cqcc, length, axis=0)
            feat_mfcc = librosa.util.fix_length(feat_mfcc, length, axis=0)
        # M = abs(spec)
        # phase = spec/(M + 2.2204e-16)
        if mode == 'cqcc':
            if i < 10:
                print("cqcc dim is", i, feat_cqcc.shape)
                print("mfcc dim is", i, feat_mfcc.shape)
            cqcc_list.append(feat_cqcc)
            mfcc_list.append(feat_mfcc)
        elif mode == 'lfcc':
            spec = librosa.util.fix_length(spec, length, axis=0)
            audio_list.append(spec.flatten())
        else:
            spec = librosa.util.fix_length(spec, length, axis=-1)
            audio_list.append(spec.flatten())
    if audio_list != []:
        return np.array(audio_list)
    else:
        return cqcc_list, mfcc_list

# load data
mode = 'cqcc'
length = 50
sr = 16000
nfft = 8192
Xtrain_file, Ytrain = load_protocal(train_file)
Xtrain_cqcc, Xtrain_mfcc = load_audio(train_dir, Xtrain_file, mode, length, sr, nfft)
np.save(data_dir + "cqcc_Xtrain_100.npy", Xtrain_cqcc)
np.save(data_dir + "mfcc_Xtrain_100.npy", Xtrain_mfcc)

Xval_file, Yval = load_protocal(dev_file)
Xval_cqcc, Xval_mfcc = load_audio(dev_dir, Xval_file, mode, length, sr, nfft)
Xtest_file, Ytest = load_protocal(eval_file)
Xtest_cqcc, Xtest_mfcc = load_audio(eval_dir, Xtest_file, mode, length, sr, nfft)
Xtrain, Xval, Ytrain, Yval = train_test_split(Xtrain, Ytrain, test_size=0.2, random_state=42, shuffle=True)
print(Xtrain_mfcc.shape, Xtest_mfcc.shape)
print(Xtest_mfcc.shape)
print('training set has %d samples, %d are genuine, %d are spoof\n' % (len(Xtrain), np.sum(Ytrain), len(Ytrain) - np.sum(Ytrain)))
print('validation set has %d samples, %d are genuine, %d are spoof\n' % (len(Xval), np.sum(Yval), len(Yval) - np.sum(Yval)))
print('test set has %d samples, %d are genuine, %d are spoof\n' % (len(Xtest), np.sum(Ytest), len(Ytest) - np.sum(Ytest)))

np.save(data_dir + "cqcc_Xtest_50.npy", Xtest_cqcc)
np.save(data_dir + "mfcc_Xtest_50.npy", Xtest_mfcc)
np.save(data_dir + "Ytest.npy", Ytest)