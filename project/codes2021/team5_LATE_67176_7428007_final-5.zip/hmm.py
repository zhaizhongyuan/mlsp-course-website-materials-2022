# -*- coding: utf-8 -*-
"""
Code for train and predict HMM
Author: An-Chen Li
"""

import gc
import os
import numpy as np
import pandas as pd
from glob import glob
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, roc_curve
import librosa
import soundfile as sf
from joblib import dump, load
from google.colab import drive
drive.mount('/content/drive', force_remount=True)

train_dir = '/content/drive/My Drive/MLSP_project/ASVspoof2017_V2_train'
dev_dir = '/content/drive/My Drive/MLSP_project/ASVspoof2017_V2_dev'
train_file = '/content/drive/My Drive/MLSP_project/protocol_V2/ASVspoof2017_V2_train.trn.txt'
dev_file = '/content/drive/My Drive/MLSP_project/protocol_V2/ASVspoof2017_V2_dev.trl.txt'
save_dir = '/content/drive/My Drive/MLSP_project/checkpoints/'

# LFCC implementation in librosa
# https://gist.github.com/RicherMans/dc1b50dd8043cee5872e0b7584f6202f
def lin(sr, n_fft, n_filter=128, fmin=0.0, fmax=None, dtype=np.float32):

    if fmax is None:
        fmax = float(sr) / 2
    # Initialize the weights
    n_filter = int(n_filter)
    weights = np.zeros((n_filter, int(1 + n_fft // 2)), dtype=dtype)

    # Center freqs of each FFT bin
    fftfreqs = librosa.fft_frequencies(sr=sr, n_fft=n_fft)

    # 'Center freqs' of liner bands - uniformly spaced between limits
    linear_f = np.linspace(fmin, fmax, n_filter + 2)

    fdiff = np.diff(linear_f)
    ramps = np.subtract.outer(linear_f, fftfreqs)

    for i in range(n_filter):
        # lower and upper slopes for all bins
        lower = -ramps[i] / fdiff[i]
        upper = ramps[i + 2] / fdiff[i + 1]

        # .. then intersect them with each other and zero
        weights[i] = np.maximum(0, np.minimum(lower, upper))

    return weights


def linear_spec(y=None,
                sr=22050,
                n_fft=2048,
                hop_length=512,
                win_length=None,
                window='hann',
                center=True,
                pad_mode='reflect',
                power=2.0,
                **kwargs):
    S = np.abs(
        librosa.core.stft(y=y,
                          n_fft=n_fft,
                          hop_length=hop_length,
                          win_length=win_length,
                          window=window,
                          center=center,
                          pad_mode=pad_mode))**power
    filter = lin(sr=sr, n_fft=n_fft, **kwargs)
    return np.dot(filter, S)


def lfcc(sig=None,
         sr=22050,
         S=None,
         n_lfcc=20,
         dct_type=2,
         norm='ortho',
         **kwargs):
    
    if S is None:
        S = librosa.power_to_db(linear_spec(y=sig, sr=sr, **kwargs))
    M = scipy.fftpack.dct(S, axis=0, type=dct_type, norm=norm)[:n_lfcc]
    return M

def load_protocal(filename):
    mapping = {'genuine': 1, 'spoof': 0}
    audio, label = [], []
    with open(filename) as f:
        for line in f:
            audio.append(line.split(' ')[0])
            label.append(mapping[line.split(' ')[1]])
    return np.array(audio), np.array(label)

def load_audio(dir, file_list, mode='melspectrogram', length=200, sr=16000):
    audio_list = []
    for entry in file_list:
        filename = dir + '/' + entry
        audio, sr = librosa.load(filename, sr=16000)
        if mode == 'stft':
            spec = librosa.stft(audio, n_fft=2048, 
                    hop_length=256, center=False, win_length=2048)
        elif mode == 'melspectrogram':
            spec = librosa.feature.melspectrogram(audio, n_fft=2048, 
                    hop_length=256, center=False, win_length=2048, sr=16000)
        elif mode == 'mfcc': # our baseline
            spec = librosa.feature.mfcc(audio, n_fft=2048, 
                    hop_length=256, center=False, win_length=2048, sr=16000)
        elif mode == 'lfcc':
            spec = lfcc(sig=audio, n_fft=2048,
                hop_length=256, center=False, win_length=2048, sr=16000)
        M = abs(spec)
        phase = spec/(M + 2.2204e-16)
        M = librosa.util.fix_length(M, length, axis=-1)
        audio_list.append(M.flatten())
    return np.array(audio_list)

class TrainHMM:
    def __init__(self, Xtrain, Ytrain):
        self.spoof = []
        self.spoof_label = 0
        self.genuine = []
        self.genuine_label = 1
        for i, data in enumerate(Ytrain):
            if data == 0:
                self.spoof.append(Xtrain[i])
            else:
                self.genuine.append(Xtrain[i])

        self.models = []
        for data, label in [[self.spoof, self.spoof_label], [self.genuine, self.genuine_label]]:
            model = hmm.GaussianHMM(n_components=4, covariance_type='diag', n_iter=1000)
            model.fit(data)
            self.models.append((model, label))

    def predict(self, Xtest, Ytest):
        Ypred = []
        for i, data in enumerate(Xtest):
            max_score = -float('inf')
            predicted_label = ""
            for model, label in self.models:
                score = model.score(data.reshape(1, -1))
                if score > max_score:
                    max_score = score
                    predicted_label = label
            Ypred.append(predicted_label)
        Ypred = np.asarray(Ypred)
        acc = get_accuracy(Ytest, Ypred)
        auc = get_auc(Ytest, Ypred)
        eer = get_eer(Ytest, Ypred)
        print(f'achieving {acc} acc and {auc} auc and {eer} eer.')

# load data
mode = 'lfcc'
length = 200
sr = 16000
Xtrain_file, Ytrain = load_protocal(train_file)
Xtrain = load_audio(train_dir, Xtrain_file, mode, length, sr)
Xtest_file, Ytest = load_protocal(dev_file)
Xtest = load_audio(dev_dir, Xtest_file, mode, length, sr)
Xtrain, Xval, Ytrain, Yval = train_test_split(Xtrain, Ytrain, test_size=0.2, random_state=42, shuffle=True)
print('training set has %d samples, %d are genuine, %d are spoof' % (len(Xtrain), np.sum(Ytrain), len(Ytrain) - np.sum(Ytrain)))
print('validation set has %d samples, %d are genuine, %d are spoof' % (len(Xval), np.sum(Yval), len(Yval) - np.sum(Yval)))
print('test set has %d samples, %d are genuine, %d are spoof\n' % (len(Xtest), np.sum(Ytest), len(Ytest) - np.sum(Ytest)))

hmm_trainer = TrainHMM(Xtrain, Ytrain)
hmm_trainer.predict(Xtest, Ytest)

# define metrics
def get_accuracy(target, pred):
    assert target.shape == pred.shape, "make sure target and prediction has the same shape"
    return np.sum(np.where(target == pred, 1, 0)) / len(target)

def get_auc(target, pred):
    return roc_auc_score(target, pred)

def get_eer(target, pred):
    fpr, tpr, threshold = roc_curve(target, pred, pos_label=1)
    fnr = 1 - tpr
    eer_threshold = threshold[np.nanargmin(np.absolute((fnr - fpr)))]
    eer = fpr[np.nanargmin(np.absolute((fnr - fpr)))]
    return eer
