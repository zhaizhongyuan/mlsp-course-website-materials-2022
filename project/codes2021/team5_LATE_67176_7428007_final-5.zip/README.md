# Team 5 - Automatic Speech Verification:
# Automatic Speech Verification Against Replay Attacks

## Authors: Yu Chu, An-Chen Li, Yuan Tang, Yi-Yu Zheng

## Abstract
Our team is working on the topic of Automatic Speech Verification against replay attacks. The system serves for the security of these voice biometric systems for real-world applications. The previous speech verification system works heavily on SVM and deep neural networks, with a benchmark of 30.6% EER given by ASVSpoof 2017 organizer. The task has two stages, where feature extraction is performed on input signal first. Features are then fed into training models, and evaluate through the test data. We have designed a series of experiments to achieve better performance with different feature extraction methods, models and parameters.

## Language
Python

## Baseline
30.6% EER given by the ASV2017 competition organizer

### data_preprocess.py
> It loads data and uses CQCC for feature extraction.
### train.py
> It ultilizes CQCC feature extraction method from data_preprocess.py and train and text data with GMM.
### hmm.py
> It ultilizes LFCC feature extraction method and train and text data with HMM.



## Result
> We have designed a series of experiments to achieve better performance with different feature extraction methods, models and parameters and achieved 27.8% EER using MFCC feature extraction and GMM classifier.

### Performance

|  Feature extraction  | Classifier | ACC | AUC | EER(Eval) |
| :------: | :-----: | :------: | :-------: | :-------: |
| MFCC | SVM | 0.702 | 0.762 | 0.297 | 
| :------: | :-----: | :------: | :-------: | :-------: |
| MFCC | GMM | 0.741 | 0.821 | 0.278 | 
| :------: | :-----: | :------: | :-------: | :-------: |
| LFCC | SVM | 0.690 | 0.751 | 0.309 | 
| :------: | :-----: | :------: | :-------: | :-------: |
| LFCC | GMM | 0.644 | 0.702 | 0.355 | 
| :------: | :-----: | :------: | :-------: | :-------: |
| CQCC | SVM | 0.581 | 0.616 | 0.418 | 
| :------: | :-----: | :------: | :-------: | :-------: |
| CQCC | GMM | 0.593 | 0.612 | 0.406 | 

### GMM Approach

> GMM is Gaussian mixture model that assumes all the data points are generated from a mixture of a finite number of Gaussian distributions that has no known parameters. 

|  system  | feature | Number of Gaussian Component | ACC | AUC | EER |
| :------: | :-----: | :------: | :-------: | :-------: | :-------: |
| GMM | mfcc | 2 | 0.682 | 0.743 | 0.318 | 
| GMM | mfcc | 5 | 0.691 | 0.750 | 0.309 | 
| GMM | mfcc | 8 | 0.671 | 0.730 | 0.329 | 
| GMM | mfcc | 16 | 0.657 | 0.705 | 0.343 | 
| GMM | mfcc | 32 | 0.639 | 0.691 | 0.361 | 
| GMM | mfcc | 72 | 0.639 | 0.704 | 0.361 | 
| GMM | mfcc | 144 | 0.648 | 0.709 | 0.352 | 

> Through the series of experiments, the combination of MFCC feature extraction method and GMM has achieved the best performance, outperforming the benchmark of 30.6% on the dataset.




