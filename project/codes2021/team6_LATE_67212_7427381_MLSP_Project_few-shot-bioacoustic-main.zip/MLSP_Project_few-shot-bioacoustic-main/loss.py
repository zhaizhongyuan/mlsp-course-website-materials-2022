import numpy as np

# Class kernel
# Class eucli:
# forward
# Backward
def euclidean_dist(x:np.ndarray, y:np.ndarray):
    '''
    Compute euclidean distance between two tensors
    '''
    # x: N x D
    # y: M x D
    n = x.shape[0]
    m = y.shape[0]
    d = x.shape[1]
    if d != y.shape[1]:
        raise Exception

    x = np.repeat(np.expand_dims(x, axis = 1), m, axis= 1)

    y = np.repeat(np.expand_dims(y, axis = 0), n, axis = 0)

    return ((x - y)**2).sum(2), 2*(x - y)


def prototypical_loss(input, target, n_support, isval = False):

    def supp_idxs(c):
        idx = np.where((target == c) > 0)[0]
        return idx[:n_support]

    def non_sup_idx(c):
        idx = np.where((target == c) > 0)[0]
        return idx[n_support:]

    classes = np.unique(target)
    n_classes = len(classes)
    p = n_classes * n_support
    n_query = (target == classes[0]).sum() - n_support
    support_idxs = list(map(supp_idxs,classes))
    prototypes = np.stack([input[idx_list].mean(0) for idx_list in support_idxs])

    query_idxs = np.stack(list(map(non_sup_idx, classes))).reshape(-1)
    query_samples = input[query_idxs]

    # dist
    dists, dist_deriv = euclidean_dist(query_samples, prototypes)
    mapclass = {}
    idx = 0
    for c in classes:
      mapclass[c] = idx
      idx += 1
    for i, t in enumerate(target):
      target[i] = mapclass[t]
    pred_label = np.argmax(-dists, axis = 1)
    acc = (pred_label == target[query_idxs]).sum()/target[query_idxs].shape[0] 
    # Derivative of the output wrt softmax
    loss = SoftmaxCrossEntropy()
    one_hot_target = np.zeros((target.size, n_classes))
    one_hot_target[np.arange(target.size), target] = 1
    loss_val = loss(-dists, one_hot_target[query_idxs, :])
    if isval:
        return loss_val.mean(), acc
    
    grad = -loss.derivative()
    # loss wrt dist
    grad = np.repeat(np.expand_dims(grad, axis = 2), dist_deriv.shape[-1], axis= 2)
    grad = grad*dist_deriv
    # dloss/d(x-y)

    grad_out = np.zeros(input.shape)
    dq = grad.sum(1) # (50, 1024)
    # dloss/dx
    grad_out[query_idxs] = dq
    dc = -grad.sum(0) # (10, 1024)
    # dloss/dy
    dsupp = (1./n_support)*np.repeat(dc, n_support, axis=0)
    grad_out[np.ravel(support_idxs)] =  dsupp
    return loss_val.mean(), acc, grad_out

## Adapted from 11-785 Introduction to Deep Learning
class SoftmaxCrossEntropy():
    def __init__(self):
        self.logits = None
        self.labels = None
        self.loss = None

    def __call__(self, x, y):
        return self.forward(x, y)

    def forward(self, x, y):
        self.logits = x
        self.labels = y

        x_sub_max = x - x.max(axis=1, keepdims=True)
        numerator = np.exp(x_sub_max)
        denominator = np.sum(numerator, axis=1, keepdims=True)
        y_hat = numerator/denominator # Softmax
        self.loss = y_hat - y

        first_term = -np.sum(y*(x_sub_max), axis = 1)
        second_term = np.sum(y*np.log(np.sum(np.exp(x_sub_max), axis=1, keepdims=True)),axis = 1)
        return first_term + second_term

    def derivative(self):
        return self.loss