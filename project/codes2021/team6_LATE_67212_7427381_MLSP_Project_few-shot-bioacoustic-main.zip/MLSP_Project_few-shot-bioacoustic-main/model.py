import numpy as np
from linear import Linear
from sigmoid import Sigmoid

class Model():
    def __init__(self):
        self.lin = Linear(17*128, 1024)
        self.log = Sigmoid()
        self.t = 0

    def __call__(self, x):
        return self.forward(x)

    def forward(self, x):
        return self.log(-self.lin(x))

    def backward(self, delta):
        # delta - (B, 1024)
        grad = delta*self.log.derivative()
        self.lin.backward(-grad)

    ## Adapted from 11-785 Introduction to Deep Learning
    def update(self, lr, beta1=0.9, beta2=0.999, eps = 1e-8):
        self.t += 1
        layer = self.lin
            # Update weights and biases here
        layer.mW = beta1*layer.mW + (1-beta1)*layer.dW
        layer.mb = beta1*layer.mb + (1-beta1)*layer.db

        layer.vW = beta2*layer.vW + (1-beta2)*(layer.dW**2)
        layer.vb = beta2*layer.vb + (1-beta2)*(layer.db**2)

        mW = layer.mW/(1 - beta1**self.t)
        mb = layer.mb/(1 - beta1**self.t)

        vW = layer.vW/(1 - beta2**self.t)
        vb = layer.vb/(1 - beta2**self.t)

        layer.W = layer.W - (lr*mW)/(np.sqrt(vW + eps))
        layer.b = layer.b - (lr*mb)/(np.sqrt(vb + eps))