import yaml
import os
import hydra
from Datagenerator import Datagen
import numpy as np
from model import Model
from batch_sampler import EpisodicBatchSampler
from loss import prototypical_loss as loss_fn
from omegaconf import DictConfig, OmegaConf


def train_protonet(model,X_train,Y_tr, X_val, Y_val,samplr_train, samplr_valid, conf,num_batches_tr,num_batches_vd):

    '''Model training
    Args:
    -model: Model
    -train_laoder: Training loader
    -valid_load: Valid loader
    -conf: configuration object
    -num_batches_tr: number of training batches
    -num_batches_vd: Number of validation batches
    Out:
    -best_val_acc: Best validation accuracy
    -model
    -best_state: State dictionary for the best validation accuracy
    '''

    num_epochs = conf.train.epochs

    best_model_path = conf.path.best_model
    last_model_path = conf.path.last_model
    train_loss = []
    val_loss = []
    train_acc = []
    val_acc = []
    best_val_acc = 0.0

    for epoch in range(num_epochs):

        print("Epoch {}".format(epoch))

        for batch in samplr_train:
            y_batch = Y_tr[batch]
            x_batch = X_train[batch]
            x_batch = np.reshape(x_batch, (x_batch.shape[0], np.prod(x_batch.shape[1:])))
            x_out = model(x_batch)
            tr_loss,tr_acc, grad = loss_fn(x_out,y_batch,conf.train.n_shot)
            train_loss.append(tr_loss.item())
            train_acc.append(tr_acc.item())

            model.backward(grad)
            model.update(conf.train.lr_rate)

        avg_loss_tr = np.mean(train_loss[-num_batches_tr:])
        avg_acc_tr = np.mean(train_acc[-num_batches_tr:])
        print('Average train loss: {}  Average training accuracy: {}'.format(avg_loss_tr,avg_acc_tr))

        for batch in samplr_valid:
            y_batch_val = Y_val[batch]
            x_batch_val = X_val[batch]
            x_batch_val = np.reshape(x_batch_val, (x_batch_val.shape[0], np.prod(x_batch_val.shape[1:])))
            x_val = model(x_batch_val)
            valid_loss, valid_acc = loss_fn(x_val, y_batch_val, conf.train.n_shot, isval=True)
            val_loss.append(valid_loss.item())
            val_acc.append(valid_acc.item())

        avg_loss_vd = np.mean(val_loss[-num_batches_vd:])
        avg_acc_vd = np.mean(val_acc[-num_batches_vd:])

        print ('Epoch {}, Validation loss {:.4f}, Validation accuracy {:.4f}'.format(epoch,avg_loss_vd,avg_acc_vd))

        if avg_acc_vd > best_val_acc:
            print("Saving the best model with valdation accuracy {}".format(avg_acc_vd))
            best_val_acc = avg_acc_vd
    #         best_state = model.state_dict()
    #         np.save(best_model_path, model.state_dict())
    # np.save(last_model_path, model.state_dict())

    return best_val_acc,model


@hydra.main(config_name="config")
def main(conf : DictConfig):

    if not os.path.isdir(conf.path.feat_path):
        os.makedirs(conf.path.feat_path)

    if not os.path.isdir(conf.path.feat_train):
        os.makedirs(conf.path.feat_train)

    if not os.path.isdir(conf.path.feat_eval):
        os.makedirs(conf.path.feat_eval)

    if conf.set.train:

        if not os.path.isdir(conf.path.Model):
            os.makedirs(conf.path.Model)

        gen_train = Datagen(conf)
        X_train,Y_train,X_val,Y_val = gen_train.generate_train()

        Y_tr = Y_train

        samples_per_cls =  conf.train.n_shot * 2

        batch_size = samples_per_cls * conf.train.k_way

        num_batches_tr = len(Y_train)//batch_size
        num_batches_vd = len(Y_val)//batch_size

        samplr_train = EpisodicBatchSampler(Y_train,num_batches_tr,conf.train.k_way,samples_per_cls)
        samplr_valid = EpisodicBatchSampler(Y_val,num_batches_vd,conf.train.k_way,samples_per_cls)

        model = Model()
        best_acc,model,best_state = train_protonet(model,X_train,Y_tr, X_val, Y_val,samplr_train, samplr_valid, conf,num_batches_tr,num_batches_vd)
        print("Best accuracy of the model on training set is {}".format(best_acc))


if __name__ == '__main__':
     main()



