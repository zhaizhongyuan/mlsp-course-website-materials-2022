import numpy as np

## ## Adapted from 11-785 Introduction to Deep Learning
class Sigmoid():

    def __init__(self):
        self.state = None

    def __call__(self, x):
        return self.forward(x)

    def forward(self, x):
        self.state = 1./(1 + np.exp(-x))
        return self.state

    def derivative(self):
        return self.state*(1-self.state)