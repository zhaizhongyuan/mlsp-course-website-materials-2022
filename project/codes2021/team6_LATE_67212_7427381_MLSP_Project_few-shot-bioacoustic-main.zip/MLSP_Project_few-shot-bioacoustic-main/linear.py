import numpy as np

## Adapted from 11-785 Introduction to Deep Learning
class Linear():
    def __init__(self, in_feature, out_feature):
        k = 1./np.sqrt(in_feature)
        self.W = np.random.uniform(-k, k, (in_feature, out_feature))
        self.b = np.random.uniform(-k, k, out_feature)

        self.dW = np.zeros((in_feature, out_feature))
        self.db = np.zeros((1, out_feature))

        #ADAM:
        self.mW = np.zeros(None) #mean derivative for W
        self.vW = np.zeros(None) #squared derivative for W
        self.mb = np.zeros(None) #mean derivative for b
        self.vb = np.zeros(None) #squared derivative for b

    def __call__(self, x):
        return self.forward(x)

    def forward(self, x):
        self.x = x
        return x@self.W + self.b

    def backward(self, delta):
        self.db = np.mean(delta, axis=0, keepdims=True)
        self.dW = (1./delta.shape[0])*(self.x.T@delta)

        return delta@self.W.T