# Few Shot Bioacoustic Event Detection


- config.yaml - Configuration file specifying hyperparameters (used by hydra framework)
- Datagenerator.py - Preprocess data from DCASE
- linear.py, loss.py, main.py, model.py, batch_sampler.py, sigmoid.py - NumPy implementation of prototypical networks
- util*.py - Utility files for model in Pytorch
- main_mod.py, main_train_final.py - Scripts to train using PyTorch


Reference:

We build upon the [DCASE Baseline](https://github.com/c4dm/dcase-few-shot-bioacoustic/tree/main/baselines/deep_learning) and implement linear and logistic models in NumPy. Some of the functions used are adapted from 11-785 Introduction to Deep Learning.