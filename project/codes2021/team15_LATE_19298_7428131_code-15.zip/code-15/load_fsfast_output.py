def load_fsfast_output(data_path, subj, method, contrast, stat_type):
    """

    load fsfast stats

    :param data_path:
    :param subjs:
    :param method:
    :param contrasts:
    :param stat_type:
    :return:
    """

    import nibabel as nib
    import glob as glob

    print(f'{subj}/lh/{method}/{contrast}/{stat_type}.nii.gz')
    print(f'{subj}/rh/{method}/{contrast}/{stat_type}.nii.gz')

    img_lh = nib.load(glob.glob(data_path + f'/{subj}/lh/{method}/{contrast}/{stat_type}.nii.gz')[0])
    img_rh = nib.load(glob.glob(data_path + f'/{subj}/rh/{method}/{contrast}/{stat_type}.nii.gz')[0])

    image_data_lh = img_lh.get_fdata()
    image_data_rh = img_rh.get_fdata()

    # data.to_excel('mri_data_excel.xlsx')

    return image_data_lh, image_data_rh