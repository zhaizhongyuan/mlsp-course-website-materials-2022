import pdb
import mne

import matplotlib.pyplot as plt
import numpy as np
import os


def run_inverse_computation(epochs, condition, fMRI_mapping=None):

    ###############################
    # compute covariance
    ###############################
    data_path = r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI'
    subjects_dir = data_path + r'\subjects_dir'

    # baseline correct before computing noise covariance with baseline signal
    # TODO: use 1.5-2.7 as ERP duration as mentioned in Winko's paper
    # baseline from -1.3 to 1.5
    epochs_bc = epochs.apply_baseline(baseline=(None, 0), verbose=True)

    # compute covariance
    noise_cov = mne.compute_covariance(epochs_bc, tmin=None, tmax=0,
                                       method=['shrunk', 'empirical'],
                                       rank=None, verbose=True)  #

    # visualize covariance
    fig_cov, fig_spectra = mne.viz.plot_cov(noise_cov, epochs.info)

    ###############################
    # evoked data
    ###############################

    # evoked data
    evoked = epochs_bc.average()
    """
    evoked.plot(time_unit='s')
    evoked.plot_topomap(times=[0.04,1.54,1.84,2.14,2.74], time_unit='s')

    # visualize
    evoked.plot_white(noise_cov, time_unit='s')
    
    """
    del epochs  # to save memory


    ###############################
    # inverse modeling
    ###############################

    # set reference to average of EEG channels here (data is already referenced to mastoid electrodes)
    evoked.set_eeg_reference(ref_channels='average', projection=True)

    # read forward solution
    fname_fwd = data_path + r'\PLT4-forward-model-ico4-fwd.fif'
    fwd = mne.read_forward_solution(fname_fwd)

    # compute inverse operator
    #inverse_operator = mne.minimum_norm.make_inverse_operator(evoked.info, fwd, noise_cov, loose=0.2, depth=0.8)
    inverse_operator_fixed = mne.minimum_norm.make_inverse_operator(evoked.info, fwd, noise_cov, loose='auto',
                                                                    fixed=True)
    del fwd

    if fMRI_mapping is None:

        print("NOT including fMRI priors in the source estimate")

        # write inverse operator to disk:
        mne.minimum_norm.write_inverse_operator(data_path + r'\PLT4-inverse-model-ico4-fwd.fif',
                                                inverse_operator_fixed)
    else:

        # edit the source covariance matrix
        # max_sc = np.max(inverse_operator_fixed['source_cov']['data'])
        fMRI_mapping = (fMRI_mapping + 0.5)/2  # try with 0.75 and 0.25 strengths
        fmri_cov = np.multiply(fMRI_mapping, inverse_operator_fixed['source_cov']['data'])
        inverse_operator_fixed['source_cov']['data'] = fmri_cov

        """
        for i in range(3):
            inverse_operator_fixed['source_nn'][:, i] = \
                np.multiply(fMRI_mapping, inverse_operator_fixed['source_nn'][:, i])
        
        for i in range(64):
            inverse_operator_fixed['eigenleads'][:, i] = \
                np.multiply(fMRI_mapping, inverse_operator_fixed['eigenleads'][:, i] )
        fmri_cov = np.multiply(fMRI_mapping, inverse_operator_fixed['source_cov']['data'])
        plt.plot(fmri_cov)
        plt.title('fMRI-Informed Covariance Matrix')
        plt.ylabel('Scaled Amplitude')
        plt.xlabel('Source Number')
        plt.show()"""

        # write inverse operator to disk:
        mne.minimum_norm.write_inverse_operator(data_path + r'\PLT4-inverse-model-ico4-fwd-fMRI.fif',
                                                inverse_operator_fixed)

    """
    # hack a label to get fMRI data going - NVMD, covariance method works :)
    lh_label = np.multiply(fMRI_mapping[0:2562], np.arange(2562))
    lh_label = lh_label[np.where(lh_label != 0)]
    rh_label = np.multiply(fMRI_mapping[2562:], 2562 + np.arange(2562))
    rh_label = rh_label[np.where(rh_label != 0)]

    class vertex:
        def __init__(self, vertices):
            self.vertices = vertices

    class label:
        def __init__(self, hemi):
            self.lh = vertex(lh_label)
            self.rh = vertex(rh_label)
            self.hemi = hemi

    # fMRI_mapping_label = {'lh': {'vertices': lh_label},
    #                 'rh': {'vertices': rh_label},
    #                 'hemi':'both'}

    fMRI_mapping_label = label('both')
    """

    # compute inverse solution
    method = "dSPM"   # TODO: try more methods
    snr = 3. # original: 3 TO-try: [1,3,10,100]
    lambda2 = 1. / snr ** 2   # TODO: try more lambda2 values, since it's no "optimal"
    stc, residual = mne.minimum_norm.apply_inverse(evoked, inverse_operator_fixed,
                                                   lambda2,method=method,
                                                   pick_ori=None,
                                                   return_residual=True,
                                                   verbose=True)
                                                   # label=fMRI_mapping_label)

    ###############################
    # visualization
    ###############################

    # visualization dipole activations
    fig, ax = plt.subplots()
    ax.plot(1e3 * stc.times, stc.data[::100, :].T)
    ax.set(xlabel='time (ms)', ylabel='%s value' % method)
    fig.show()


    '''
    # visualize residual after fitting 
    fig, axes = plt.subplots(2, 1)
    evoked.plot(axes=axes)
    for ax in axes:
        ax.texts.clear()
        for line in ax.lines:
            line.set_color('#98df81')
    residual.plot(axes=axes)'''


    # visualize source in 3D
    vertno_max, time_max = stc.get_peak(hemi=None) # hemi='rh'

    surfer_kwargs = dict(hemi='both', subjects_dir=subjects_dir,
                         views='lateral', size=(800, 800), smoothing_steps=10)
    # hemi could be lh, rh, both or split
    # TODO: lims?

    mean_brain = stc.mean().plot(**surfer_kwargs)
    plt.show()
    #brain = stc.plot(**surfer_kwargs)

    #brain.add_foci(vertno_max, coords_as_verts=True, hemi=None, color='blue',scale_factor=0.6, alpha=0.5) # this hemi could not be both when both hemis are displayed

    mean_brain.add_text(0.1, 0.9, f'{method} (mean fMRI-constrained activation)', 'title',
                font_size=14)

    # The documentation website's movie is generated with:
    #brain.save_movie('source_movie_cond'+str(condition)+'.mov', interpolation='linear',time_dilation=20, framerate=10) # tmin=0.05, tmax=0.15, , time_viewer=True