"""


Eli Bulger

FSFAST Analysis Script

October 2021

"""

def plot_fsfast_stats(subj, contrast, image_data_lh, image_data_rh,
                      view_type, stat_type, method, title, save, show, cbar_max=None, label=None, nilearn=None):
    """

    :param subj:
    :param contrast:
    :param image_data_lh:
    :param image_data_rh:
    :param view_type:
    :param stat_type:
    :param method:
    :param title:
    :param save:
    :param show:
    :param cbar_max:
    :param label:
    :return:
    """

    from nilearn.plotting import plot_stat_map
    from nilearn import datasets, surface, plotting
    import numpy as np
    from matplotlib import pyplot as plt
    import matplotlib.patches as mpatches

    big_fsaverage = datasets.fetch_surf_fsaverage('fsaverage')
    coords, faces = surface.load_surf_mesh(big_fsaverage.infl_right)
    # right side
    # pos_val_rh = np.percentile(image_data_rh, 99)
    # neg_val_rh = np.abs(np.percentile(image_data_rh, 1))
    # max_val_rh = np.max(np.abs(image_data_rh))

    plt.close('all')

    fig, axes = plt.subplots(1, 1, subplot_kw={'projection': '3d'})
    plotting.plot_surf_stat_map(big_fsaverage.infl_right,
                                image_data_rh,
                                hemi='right',
                                colorbar=True,
                                title=f'Intask (right hemisphere surface) - {title}',
                                threshold=2,
                                view=view_type,
                                bg_map=big_fsaverage.sulc_right,
                                vmax=cbar_max,
                                axes=axes)
    if label is not None:
        plotting.plot_surf_contours(big_fsaverage.infl_right,
                                    roi_map=label[0],
                                    figure=fig,
                                    axes=axes)
        """        
        color='green'
        reg_name = 'label-name'
        patch_list = []
        faces_outside = get_faces(faces, label[0])
        modify_facecolors('green', faces_outside, axes)
        patch_list.append(mpatches.Patch(color=color, label=reg_name))
        fig.legend(handles=patch_list)
        """

    if show is True:
        plotting.show()
    if save is True:
        fig.savefig(f"{subj}_{stat_type}-stat_rh_{contrast}-{method}-{view_type}-{title}.png", dpi=300,
                    bbox_inches='tight')

    # left side
    # pos_val_lh = np.percentile(image_data_lh, 99)
    # neg_val_lh = np.abs(np.percentile(image_data_lh, 1))
    # max_val_lh = np.max(np.abs(image_data_lh))
    coords2, faces2 = surface.load_surf_mesh(big_fsaverage.infl_left)

    fig2, axes2 = plt.subplots(1, 1, subplot_kw={'projection': '3d'})
    plotting.plot_surf_stat_map(big_fsaverage.infl_left,
                                image_data_lh,
                                hemi='left',
                                colorbar=True,
                                title=f'Intask (left hemisphere surface) - {title}',
                                threshold=2,
                                view=view_type,
                                bg_map=big_fsaverage.sulc_left,
                                vmax=cbar_max,
                                axes=axes2)

    if label is not None:
        plotting.plot_surf_contours(big_fsaverage.infl_left, roi_map=label[1], figure=fig2, axes=axes2, levels=[1])
        """
        color='green'
        reg_name = 'label-name'
        patch_list = []
        faces_outside = get_faces(faces, label[1])
        modify_facecolors('green', faces_outside, axes2)
        patch_list.append(mpatches.Patch(color=color, label=reg_name))
        fig2.legend(handles=patch_list)
        """

    if show is True:
        plotting.show()

    if save is True:
        fig2.savefig(f"{subj}_{stat_type}-stat_lh_{contrast}-{method}-{view_type}-{title}.png", dpi=300,
                     bbox_inches='tight')