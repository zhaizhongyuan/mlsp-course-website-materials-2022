

from inverse_model_eli import *
import mne
import mayavi
import nibabel
from mne.io import read_info
import numpy as np
from load_fsfast_output import load_fsfast_output
from plot_fsfast_stats import plot_fsfast_stats
from get_SS_mapping import get_SS_mapping

subject = 'sub-PLT4'
base_path = r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI'
subjects_dir = base_path + r'\subjects_dir'
datapath =  base_path + r'\RSAS_PLT4_Combined.set'
fmri_data_path = base_path + r'\fsfast-functional'
ss_data_path = base_path
trans = base_path + r'\sub-PLT4-trans.fif'

# -----------------------------------------------------------------
# ---------------            EEG data            ------------------
# -----------------------------------------------------------------

# get the epoched data (cluster location version)
epochs = mne.io.read_epochs_eeglab(base_path + r'\RSAS_PLT4_Combined.set')
epochs.rename_channels({'Afz':'AFz'})
biosemi_montage = mne.channels.make_standard_montage('biosemi64')
# biosemi_montage.plot()
epochs.set_montage(biosemi_montage)

# -----------------------------------------------------------------
# ---------------            fMRI data           ------------------
# -----------------------------------------------------------------
method = 'no-reg'
stat_type = 't'
contrast = 'SvR'


# load the fMRI data
image_data_lh, image_data_rh = load_fsfast_output(fmri_data_path, subject, method, contrast, stat_type)

fname_fwd = ss_data_path + r'\PLT4-forward-model-ico4-fwd.fif'
fwd = mne.read_forward_solution(fname_fwd)

sources = fwd['src']

# getting the morph object
# morph = mne.compute_source_morph(sources, subject_to='fsaverage', subjects_dir=subjects_dir)
morphed_spaces = mne.morph_source_spaces(sources,  subject_to='fsaverage', subjects_dir=subjects_dir)

# if we can get the morph matrix from fsaverage 5 spacing to our subject specific source space,
# we can apply the labels we want to fsaverage space and determine which ones survive the source space morphing,
# then update those in the covariance matrix :)

# function that returns the most highly activated vertices according to fMRI activation
top_50_fmri_in_source_space_lh, top_50_fmri_in_source_space_rh, \
fmri_data_boolean_lh, fmri_data_boolean_rh = get_SS_mapping(morphed_spaces, image_data_lh, image_data_rh)

# -----------------------------------------------------------------
# ---------------            INVERSE MODEL       ------------------
# -----------------------------------------------------------------
# get all event ids, select all those start with what I want, save the list for ids of interest
# epochs.event_id is a dict, length 747

cond_comp1 = [3, 4] # [1,2,3,4]# [4]
cond_comp2 = [17, 18] # [5,6,7,8] #[8]

cond_comp1_str = np.array(cond_comp1).astype(str)
cond_comp2_str = np.array(cond_comp2).astype(str)

matching_comp1 = [s for s in epochs.event_id if (s.split('/')[0] == cond_comp1_str).any()] #==str(cond_comp1)
epochs_comp1 = epochs[matching_comp1]
matching_comp2 = [s for s in epochs.event_id if (s.split('/')[0] == cond_comp2_str).any()]
epochs_comp2 = epochs[matching_comp2]

run_inverse_computation(epochs_comp1, condition=''.join(cond_comp1_str), fMRI_mapping=np.concatenate([top_50_fmri_in_source_space_lh,
                                                                          top_50_fmri_in_source_space_lh]))

run_inverse_computation(epochs_comp2,condition=''.join(cond_comp2_str), fMRI_mapping=np.concatenate([top_50_fmri_in_source_space_lh,
                                                                          top_50_fmri_in_source_space_lh]))
