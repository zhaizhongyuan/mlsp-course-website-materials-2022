"""

MLSP 2021 Project

Eli Bulger, Wusheng Liang Jingyi Wu

Need to run this on the cluster, because that's where freesurfer is installed...

"""



import mne

subject = 'sub-PLT4'
subjects_dir = r'/lab_data/barblab/Eli/RSA/BIDS/derivatives/fmriprep-20.2.1/freesurfer/'

# get the epoched data (cluster location version)
epochs = mne.io.read_epochs_eeglab(r'/lab_data/barblab/Winko/Research_Data/BU/BURSAS_RSAStudy/EEG/5_z1_preRDM/RSAS_PLT4_Combined.set')

# run the BEM code
mne.bem.make_watershed_bem(subject, subjects_dir=subjects_dir)
