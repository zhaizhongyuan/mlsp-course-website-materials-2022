
def get_SS_mapping(morph, image_data_lh, image_data_rh, percentile=50):
    """

    function to get top 'percentile' percent of fMRI constrast activation data,
    and return as boolean array for covariance matrix editing in EEG source localisation

    :param morph: morphed sources object (after applying morph, it holds vertices converted from)
    :param image_data_lh:
    :param image_data_rh:
    :param percentile:
    :return:
    """

    import numpy as np

    # arrays that hold the indices of the fsaverage spaces in the inputted source space
    fsaverage2ss_lh = morph[0]['vertno']
    fsaverage2ss_rh = morph[1]['vertno']

    # len(morph.morph_mat.indices) = 146971 (ico 4 space)

    # take top 50% percentile of positive values to get most activated regions during spatial trials
    p50_lh = np.percentile(image_data_lh[image_data_lh > 0], q=percentile, axis=0)
    p50_rh = np.percentile(image_data_rh[image_data_rh > 0], q=percentile, axis=0)

    # then get values >= 50
    fmri_data_boolean_lh = image_data_lh > p50_lh
    fmri_data_boolean_rh = image_data_rh > p50_rh

    fmri_data_boolean_lh = fmri_data_boolean_lh.astype(int)
    fmri_data_boolean_rh = fmri_data_boolean_rh.astype(int)

    # convert boolean lh and rh to source space!!!
    top_50_fmri_in_source_space_lh = np.ravel(fmri_data_boolean_lh[fsaverage2ss_lh])
    top_50_fmri_in_source_space_rh = np.ravel(fmri_data_boolean_rh[fsaverage2ss_rh])

    return top_50_fmri_in_source_space_lh, top_50_fmri_in_source_space_rh, fmri_data_boolean_lh, fmri_data_boolean_rh

