"""

MLSP 2021 Project

Eli Bulger
members - Wusheng Liang Jingyi Wu

Need to run this on the cluster, because that's where freesurfer is installed...

"""

import mne
import mayavi
import nibabel
from mne.io import read_info
import numpy as np
from load_fsfast_output import load_fsfast_output
from plot_fsfast_stats import plot_fsfast_stats
from get_SS_mapping import get_SS_mapping

subject = 'sub-PLT4'
subjects_dir = r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\subjects_dir'
datapath = r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\RSAS_PLT4_Combined.set'

# get the epoched data (cluster location version)
epochs = mne.io.read_epochs_eeglab(r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\RSAS_PLT4_Combined.set')
epochs.rename_channels({'Afz':'AFz'})
biosemi_montage = mne.channels.make_standard_montage('biosemi64')
# biosemi_montage.plot()
epochs.set_montage(biosemi_montage)
trans = r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\sub-PLT4-trans.fif'
# biosemi_montage.save(r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\biosemi_montage_digitization-100.fif')

info = epochs.info


mne.viz.plot_bem(subject=subject, subjects_dir=subjects_dir,
                 brain_surfaces='white', orientation='coronal')

# visualise the projected EEG locations (projected onto the head, taken from Freesurfer)
mne.viz.plot_alignment(info=info,
                       trans=trans,
                       subject=subject,
                       subjects_dir=subjects_dir, surfaces='auto',
                       coord_frame='head', meg=None, eeg='projected',
                       fwd=None, dig=False, ecog=False, src=None,
                       mri_fiducials=False, bem=None, seeg=True,
                       fnirs=False, show_axes=False, dbs=False, fig=None,
                       interaction='trackball', verbose=None)

# # set up the source space --- this takes a significant amount of time to compute
# sources = mne.setup_source_space(subject, spacing='ico4', surface='white',
#                                 subjects_dir=subjects_dir, add_dist=True,
#                                 n_jobs=1, verbose=None)

sources = mne.read_source_spaces(r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\PLT4-ico4-src.fif')

# fMRI data

method = 'no-reg'
stat_type = 't'
contrast = 'SvR'
fmri_data_path = r"C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\fsfast-functional"

# load the fMRI data
image_data_lh, image_data_rh = load_fsfast_output(fmri_data_path, subject, method, contrast, stat_type)

plot_fsfast_stats(subject, contrast, image_data_lh, image_data_rh,
                  'lateral', stat_type, method,
                  'Subject fMRI Activation Data - Thresholded', save=True, show=True)

# now we have 2 arrays of size (163842, 1, 1, 1)

# need to plot this

# take some threshold
# getting the morph object
morph = mne.compute_source_morph(sources, subject_to='fsaverage', subjects_dir=subjects_dir)

morphed_spaces = mne.morph_source_spaces(sources,  subject_to='fsaverage', subjects_dir=subjects_dir)

# if we can get the morph matrix from fsaverage 5 spacing to our subject specific source space,
# we can apply the labels we want to fsaverage space and determine which ones survive the source space morphing,
# then update those in the covariance matrix :)

top_50_fmri_in_source_space_lh, top_50_fmri_in_source_space_rh, \
fmri_data_boolean_lh, fmri_data_boolean_rh = get_SS_mapping(morphed_spaces, image_data_lh, image_data_rh)

# visualise the sources?
mne.viz.plot_bem(subject=subject, subjects_dir=subjects_dir,
                 brain_surfaces='white', src=sources, orientation='coronal')

# view the sources in 3 dimensions
fig = mne.viz.plot_alignment(info=info,
                             subject=subject,
                             subjects_dir=subjects_dir,
                             trans=trans,
                             surfaces=dict(white=0.6, outer_skull=0.2, head=0.2),
                             coord_frame='head',
                             eeg='projected',
                             src=sources)
mne.viz.set_3d_view(fig, azimuth=173.78, elevation=101.75,
                    distance=0.30, focalpoint=(-0.03, -0.01, 0.03))


conductivity = (0.3, 0.006, 0.3)  # for three layers, EEG
model = mne.make_bem_model(subject=subject, conductivity=conductivity, subjects_dir=subjects_dir, ico=4)
bem = mne.make_bem_solution(model)
mne.write_bem_solution(r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\PLT4-5120-5120-5120-bem-ico4-sol.fif', bem)

#  it is important to pass fwd['src'] or inv['src'] so that
#  removal of some sources in bem model is adequately accounted for

# compute forward solution
fwd = mne.make_forward_solution(info, trans=trans, src=sources, bem=bem,
                                meg=False, eeg=True, mindist=5.0, n_jobs=1,
                                verbose=True)
mne.write_forward_solution(r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\PLT4-forward-model-ico4-fwd.fif', fwd)

# STUFF THAT NEEDS TO BE RUN IN THE TERMINAL OR ON THE CLUSTER
# run the BEM code
# mne.bem.make_watershed_bem(subject, subjects_dir=subjects_dir)
# mne.viz.plot_bem(subject=subject, subjects_dir=subjects_dir, orientation='coronal')
#mne.gui.coregistration(subject, subjects_dir=subjects_dir)

