# mlsp-project-2021

## Files included

- run_inverse_model.py: run this script to run inverse computation
- inverse_model.py: a function containing every step in inverse model computation (EEG only)


## Environment
PC1: MacOS + Python 3.9.7 + Numpy 1.20.3 + MNE 0.24.0 + matplotlib 3.4.3 


## Run forward model
Preliminaries
- creating the BEM for the subject-specific head model was done using freesurfer / MNE software on a computing cluster (for the sole purpose of this project)
- the projection of the EEG montage onto the subject-specific head surface was done using a GUI-based mne "coregistration function"
- plot_fsfast_stats.py - plots the fMRI data

coregistration.py and coregistration_fmri.py were used to calculate the forward model. In coregistration_fmri:
- line 56: sets up / reads the source space
- line 66: loads the preprocessed fMRI data
- line 78: computes a morphing between standard fsaverage space and our subject-specific source space
- line 86: get_SS_mapping gets the vertices we are interested in by accessing the morph attributes
- line 77: makes the BEM model
- line 115: makes the forward model

## Run inverse model

Run run_inverse_model.py to compute EEG-only inverse solution. 
A few parameters could try to adjust:
- line 53 in inverse_model.py: change loose and depth to fit different assumptions about the sources
- line 65 change inverse computation method, options including 'MNE', 'dSPM', and 'sLORETA'
- line 66 & 67 in inverse_model.py: adjust regularization parameter lambda

The "eli" version includes fMRI prior implementation (lines 64-92).

## Combined Script (full_SL_fMRI.py
This script takes components of both of the above forward and inverse model codes, and incorporates that into a full source localization script.

## Other
- load_fsfast_output.py is a function that loads the fMRI data

Please don't hesitate to reach out if you have any questions!

___

**
Also a note on evaluation metrics - most of our questions in piazza were based on how to evaluate our project results. Halfway through the term we reached out to course staff regarding this but unfortunately did not hear back. We also did not receive feedback on the proposal. We hope our answers addressing evaluation on piazza were satisfactory and this is kept in mind! Thank you!
**
