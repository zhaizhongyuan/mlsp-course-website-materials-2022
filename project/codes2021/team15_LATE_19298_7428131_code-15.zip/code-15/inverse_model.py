import pdb
import mne

import matplotlib.pyplot as plt
import numpy as np
import os



def run_inverse_computation(epochs,condition):

    ###############################
    # compute covariance 
    ###############################

    # baseline correct before computing noise covariance with baseline signal
    # TODO: use 1.5-2.7 as ERP duration as mentioned in Winko's paper
    # baseline from -1.3 to 1.5
    epochs_bc = epochs.apply_baseline(baseline=(None,0),verbose=True)

    # compute covariance
    noise_cov = mne.compute_covariance(epochs_bc, tmin=None, tmax=0, method=['shrunk', 'empirical'], rank=None, verbose=True) # 

    # visualize covariance
    fig_cov, fig_spectra = mne.viz.plot_cov(noise_cov, epochs.info)


    ###############################
    # evoked data
    ###############################

    # evoked data
    evoked = epochs_bc.average()
    evoked.plot(time_unit='s')
    evoked.plot_topomap(times=[0.04,1.54,1.84,2.14,2.74], time_unit='s') 

    # visualize
    evoked.plot_white(noise_cov, time_unit='s')
    del epochs  # to save memory


    ###############################
    # inverse modeling
    ###############################

    # read forward solution 
    fname_fwd = './data/PLT4-forward-model-ico4-fwd.fif'
    fwd = mne.read_forward_solution(fname_fwd)

    # TODO: try loose = auto? try depth compute with mne.forward.compute_depth_prior?

    # compute inverse operator
    inverse_operator = mne.minimum_norm.make_inverse_operator(evoked.info, fwd, noise_cov, loose=0, depth=None)
    del fwd

    pdb.set_trace()

    # write inverse operator to disk: 
    mne.minimum_norm.write_inverse_operator('./data/new_PLT4-inverse-operator-ico4-cond'+str(condition)+'.fif', inverse_operator)


    evoked.set_eeg_reference(ref_channels='average', projection=True) # TODO: not sure about this step

    # compute inverse solution
    method = "sLORETA" # TODO: try more methods
    snr = 3. # original: 3 TO-try: [1,3,10,100]
    lambda2 = 1. / snr ** 2 # TODO: try more lambda2 values, since it's no "optimal"
    stc, residual = mne.minimum_norm.apply_inverse(evoked, inverse_operator, lambda2,method=method, pick_ori=None,return_residual=True, verbose=True)


    ###############################
    # visualization
    ###############################

    # visualization dipole activations
    fig, ax = plt.subplots()
    ax.plot(1e3 * stc.times, stc.data[::100, :].T)
    ax.set(xlabel='time (ms)', ylabel='%s value' % method)
    fig.show()

    pdb.set_trace()


    '''
    # visualize residual after fitting 
    fig, axes = plt.subplots(2, 1)
    evoked.plot(axes=axes)
    for ax in axes:
        ax.texts.clear()
        for line in ax.lines:
            line.set_color('#98df81')
    residual.plot(axes=axes)'''


    # visualize source in 3D
    vertno_max, time_max = stc.get_peak(hemi=None) # hemi='rh'

    subjects_dir = './data/subjects_dir' 
    surfer_kwargs = dict(hemi='both', subjects_dir=subjects_dir,clim=dict(kind='value', lims=[1, 3, 6]), views='lateral',initial_time=time_max, time_unit='s', size=(800, 800), smoothing_steps=10)
    # hemi could be lh, rh, both or split
    # TODO: lims?

    brain = stc.plot(**surfer_kwargs)

    #brain.add_foci(vertno_max, coords_as_verts=True, hemi=None, color='blue',scale_factor=0.6, alpha=0.5) # this hemi could not be both when both hemis are displayed 

    brain.add_text(0.1, 0.9, 'dSPM (plus location of maximal activation)', 'title',
                font_size=14)

    # The documentation website's movie is generated with:
    #brain.save_movie('source_movie_cond'+str(condition)+'.mov', interpolation='linear',time_dilation=20, framerate=10) # tmin=0.05, tmax=0.15, , time_viewer=True


    pdb.set_trace()