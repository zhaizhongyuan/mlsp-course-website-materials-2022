
import pdb
import mne

import matplotlib.pyplot as plt
import numpy as np
import os

from inverse_model import *



###############################
# load data
###############################
'''
The data uploaded to the drive is epoch data, not raw, should use read_epochs_eeglab instead of read_raw_eeglab
'''

#raw_path = './data/'

fpath = './data/RSAS_PLT4_Combined.set'
epochs = mne.io.read_epochs_eeglab(fpath)

#raw = mne.io.read_raw_eeglab(fpath,preload=False)
#pdb.set_trace()
#raw.plot(duration=60)
#epochs = raw


# epochs.info
# epochs.ch_names
# epochs.event_id


###############################
# visualization
###############################

#epochs.plot()

#epochs.plot(n_epoch = 1)

###############################
# selecting epochs
###############################

# comparing spatial attention 
# D1 is always presented from center 
# comparing D2 location at 90 degree opposite side to the target 
# same gender speaker (rule out other differences) 

# condition 4: target left, D2 right, same gender, look for '4/99'
# condition 8: target right, D2 left, same gender, look for '8/99'

# D2 onset time: either before or after target 



# get all event ids, select all those start with what I want, save the list for ids of interest 
# epochs.event_id is a dict, length 747

cond_comp1 = [3,4] # [1,2,3,4]# [4] 
cond_comp2 = [17,18] # [5,6,7,8] #[8]

cond_comp1_str = np.array(cond_comp1).astype(str)
cond_comp2_str = np.array(cond_comp2).astype(str)


matching_comp1 = [s for s in epochs.event_id if (s.split('/')[0] == cond_comp1_str).any()] #==str(cond_comp1)
epochs_comp1 = epochs[matching_comp1]
matching_comp2 = [s for s in epochs.event_id if (s.split('/')[0] == cond_comp2_str).any()]
epochs_comp2 = epochs[matching_comp2]


# epoch again to 1.5-2.7

# epochs.plot_image(picks=['Cz'])


#pdb.set_trace()

#from mne.time_frequency import tfr_morlet
#freqs = np.logspace(*np.log10([6, 35]), num=8)
#n_cycles = freqs / 2.  # different number of cycle per frequency
#power, itc = tfr_morlet(epochs_comp1, freqs=freqs, n_cycles=n_cycles, use_fft=True,return_itc=True, decim=3, n_jobs=1)
# power.plot_topo(baseline=(-0.5, 0), mode='logratio', title='Average power')

#epochs_comp1.set_eeg_reference(ref_channels='average', projection=True)
#epochs_comp1_ave = epochs_comp1.average()
#epochs_comp1_ave.plot(spatial_colors=True)
#epochs_comp1_ave.plot_topomap(times=[1.3,1.8,2.1,2.7])
#epochs_comp1_ave.plot_joint()

run_inverse_computation(epochs_comp1,condition=''.join(cond_comp1_str))#''.join(cond_comp1_str)

pdb.set_trace()

run_inverse_computation(epochs_comp2,condition=''.join(cond_comp2_str))#'8'

pdb.set_trace()


