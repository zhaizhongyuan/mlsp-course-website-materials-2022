"""

MLSP 2021 Project

Eli Bulger
Wusheng Liang Jingyi Wu

Need to run this on the cluster, because that's where freesurfer is installed...

"""

import mne
import mayavi
import nibabel
from mne.io import read_info

subject = 'sub-PLT4'
subjects_dir = r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\subjects_dir'
datapath = r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\RSAS_PLT4_Combined.set'

# get the epoched data (cluster location version)
epochs = mne.io.read_epochs_eeglab(r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\RSAS_PLT4_Combined.set')
epochs.rename_channels({'Afz':'AFz'})
biosemi_montage = mne.channels.make_standard_montage('biosemi64')
# biosemi_montage.plot()
epochs.set_montage(biosemi_montage)
trans = r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\PLT4-trans.fif'


info = epochs.info


# info = mne.io.read_info(trans)

# visualise the projected EEG locations (projected onto the head, taken from Freesurfer)
mne.viz.plot_alignment(info=info,
                       trans=trans,
                       subject=subject,
                       subjects_dir=subjects_dir, surfaces='auto',
                       coord_frame='head', meg=None, eeg='original',
                       fwd=None, dig=False, ecog=False, src=None,
                       mri_fiducials=False, bem=None, seeg=True,
                       fnirs=True, show_axes=False, dbs=True, fig=None,
                       interaction='trackball', verbose=None)

# set up the source space --- this takes a significant amount of time to compute
sources = mne.setup_source_space(subject, spacing='ico4', surface='white',
                                subjects_dir=subjects_dir, add_dist=True,
                                n_jobs=1, verbose=None)
mne.write_source_spaces(r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\PLT4-ico4-src.fif', sources)

# read the source spaces
sources = mne.read_source_spaces()

# visualise the sources?
mne.viz.plot_bem(subject=subject, subjects_dir=subjects_dir,
                 brain_surfaces='white', src=sources, orientation='coronal')

# view the sources in 3 dimensions
fig = mne.viz.plot_alignment(subject=subject, subjects_dir=subjects_dir,
                             surfaces='white', coord_frame='head',
                             src=sources)
mne.viz.set_3d_view(fig, azimuth=173.78, elevation=101.75,
                    distance=0.30, focalpoint=(-0.03, -0.01, 0.03))


conductivity = (0.3, 0.006, 0.3)  # for three layers, EEG
model = mne.make_bem_model(subject=subject, conductivity=conductivity, subjects_dir=subjects_dir, ico=4)
bem = mne.make_bem_solution(model)
mne.write_bem_solution(r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\PLT4-5120-5120-5120-bem-ico4-sol.fif', bem)

#  it is important to pass fwd['src'] or inv['src'] so that
#  removal of some sources in bem model is adequately accounted for

# compute forward solution
fwd = mne.make_forward_solution(info, trans=trans, src=sources, bem=bem,
                                meg=False, eeg=True, mindist=5.0, n_jobs=1,
                                verbose=True)
mne.write_forward_solution(r'C:\Users\elibu\PycharmProjects\MLSP-EEG-fMRI\PLT4-forward-model-ico4-fwd.fif', fwd)



















# STUFF THAT NEEDS TO BE RUN IN THE TERMINAL OR ON THE CLUSTER
# run the BEM code
# mne.bem.make_watershed_bem(subject, subjects_dir=subjects_dir)
# mne.viz.plot_bem(subject=subject, subjects_dir=subjects_dir, orientation='coronal')
# mne.bem.make_scalp_surfaces(subject, subjects_dir=subjects_dir)
#mne.gui.coregistration(subject, subjects_dir=subjects_dir)
